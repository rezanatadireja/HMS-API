<?php

// use App\Constants\AccountTypeConstants;


return [

        'lip-document'=>env('LIP_DOCUMENT'),
        'user-job'=>env('USER_JOB')

        // 'normal-ballance' => [
        //     AccountBallanceConstants::DEBIT => 'Debit',
        //     AccountBallanceConstants::KREDIT => 'Kredit'
        // ],

];
