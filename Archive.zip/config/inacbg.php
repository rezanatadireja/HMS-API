<?php

return [
    'key' => env('INACBG_KEY'),
    'base_url' => env('INACBG_BASE_URL')
];
