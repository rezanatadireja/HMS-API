<?php

return [
	'success' => [
		'created' => 'Data berhasil disimpan.',
		'updated' => 'Data berhasil diperbarui.',
		'deleted' => 'Data berhasil dihapus.',
		'approve' => 'Data berhasil disetujui.',
        'activate' => 'Data berhasil Di aktifkan.',
        'deactivate' => 'Data berhasil Di Nonaktifkan.',
		'open' =>'Open.',
		'onprogress' =>'On Progress.',
		'done' =>'Selesai.',
		'disposition' => 'Berhasil melakukan disposisi surat.',
		'decline' => 'Data yang diajukan berhasil dikembalikan.',
		'login' => 'Berhasil login.',
		'logout' => 'Berhasil logout.',
		'ordering' => 'Berhasil melakukan penyusunan menu.',
		'download' => 'Berhasil melakukan download file.',
		'generate' => 'Berhasil membuat sertifikat file.',
		'reject' => 'Data berhasil dikembalikan.',
		'publish' => 'Data berhasil diterbitkan.',
		'signed' => 'Berhasil melakukan tanda tangan.',
		'follow-up' => 'Berhasil melakukan tindak lanjut surat.',
		'sync' => 'Berhasil melakukan Sinkronisasi',
        'permissiongeneratesuccess' => 'Berhasil membuat Permission.',
        'permissiongeneratefailed' => 'Generate Permission Gagal.',
        'permissiongenerateinvalid' => 'Invalid Parameter.',
	],
	'error' => [
		'logout' => 'Gagal melakukan logout.',
		'created' => 'Gagal melakukan menyimpan data.',
		'updated' => 'Gagal melakukan pembaharuan data.',
		'deleted' => 'Gagal melakukan penghapusan data.',
		'approve' => 'Gagal melakukan persetujuan data.',
		'generate' => 'Kunci Rahasia yang anda masukan salah. ',
		'publish' => 'Gagal melakukan penerbitan data. ',
	]
];
