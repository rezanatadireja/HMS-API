<?php

return [
    'vclaim' => [
		'cons_id' => env('VCLAIM_CONS_ID'),
        'secret_key' => env('VCLAIM_SECRET_KEY'),
        'user_key' => env('VCLAIM_USER_KEY'),
        'base_url' => env('VCLAIM_BASE_URL'),
        'service_name' => env('VCLAIM_SERVICE_NAME')
	],
    'antrean' => [
		'cons_id' => env('ANTREAN_CONS_ID'),
        'secret_key' => env('ANTREAN_SECRET_KEY'),
        'user_key' => env('ANTREAN_USER_KEY'),
        'base_url' => env('ANTREAN_BASE_URL'),
        'service_name' => env('ANTREAN_SERVICE_NAME')
	],
    'cons_id' => env('BPJS_CONS_ID'),
    'secret_key' => env('BPJS_SECRET_KEY'),
    'base_url' => env('BPJS_BASE_URL'),
    'service_name' => env('BPJS_SERVICE_NAME'),
    'user_key' => env('BPJS_USER_KEY')
];
