<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\Auth\AuthLoginController;
use App\Http\Controllers\PermissionController;

Route::group(['prefix' => 'v1'], function () {
    Route::post('authentications/register', [AuthLoginController::class, 'register'])->name('api-authentications.register');
    Route::post('authentications/login', [AuthLoginController::class, 'login'])->name('api-authentications.login');

    Route::group(['middleware' => ['jwt.verify']], function () {
        Route::post('authentications/logout', [AuthLoginController::class, 'logout'])->name('api-authentications.logout');
    });

    require __DIR__ . '/data-master/Permission.php';

    require __DIR__ . '/data-master/Role.php';

    require __DIR__ . '/data-master/User.php';

    require __DIR__ . '/data-master/MenuManagement.php';

    require __DIR__ . '/data-master/StandarReferenceGroup.php';

    require __DIR__ . '/data-master/StandarReference.php';

    require __DIR__ . '/data-master/Building.php';

    require __DIR__ . '/data-master/AppParameter.php';

    require __DIR__ . '/data-master/StandarReference.php';

    require __DIR__ . '/data-master/StandarReferenceItem.php';

    require __DIR__ . '/data-master/DepartmentType.php';

    require __DIR__ . '/data-master/Floor.php';

    require __DIR__ . '/data-master/Smf.php';

    require __DIR__ . '/data-master/Class.php';

    require __DIR__ . '/data-master/HealthServiceProvider.php';

    require __DIR__ . '/data-master/ItemGroup.php';

    require __DIR__ . '/data-master/Item.php';

    require __DIR__ . '/data-master/Guarantor.php';

    require __DIR__ . '/data-master/Department.php';

    require __DIR__ . '/data-master/ServiceRoom.php';

    require __DIR__ . '/data-master/Bed.php';

    require __DIR__ . '/data-master/OperationalTime.php';

    require __DIR__ . '/data-master/Paramedic.php';

    require __DIR__ . '/data-master/ParamedicSchedule.php'; 

    require __DIR__ . '/data-master/ParamedicScheduleDate.php';

    require __DIR__ . '/data-master/Location.php';
});
