<?php

use App\Http\Controllers\DataMaster\StandarReferenceItemController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('standar-reference-items', [App\Http\Controllers\DataMaster\StandarReferenceItemController::class, 'data'])->name('standar-reference-items.data');

    Route::post('standar-reference-items', [App\Http\Controllers\DataMaster\StandarReferenceItemController::class, 'store'])->name('standar-reference-items.create');

    Route::get('standar-reference-items/{id}', [App\Http\Controllers\DataMaster\StandarReferenceItemController::class, 'show'])->name('standar-reference-items.show');

    Route::put('standar-reference-items/{id}', [App\Http\Controllers\DataMaster\StandarReferenceItemController::class, 'update'])->name('standar-reference-items.update');

    Route::delete('standar-reference-items/{id}', [App\Http\Controllers\DataMaster\StandarReferenceItemController::class, 'delete'])->name('standar-reference-items.delete');

    Route::put('standar-reference-items/status-update/{id}', [App\Http\Controllers\DataMaster\StandarReferenceItemController::class, 'status_update'])->name('standar-reference-items.status-update');

});
