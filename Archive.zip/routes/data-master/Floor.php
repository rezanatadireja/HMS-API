<?php

use App\Http\Controllers\DataMaster\FloorController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('floors', [FloorController::class, 'data'])->name('floors.data');

    Route::post('floors', [FloorController::class, 'store'])->name('floors.store');

    Route::get('floors/{id}', [FloorController::class, 'show'])->name('floors.show');

    Route::put('floors/{id}', [FloorController::class, 'update'])->name('floors.update');

    Route::delete('floors/{id}', [FloorController::class, 'destroy'])->name('floors.delete');

    Route::put('floors/{id}/status', [FloorController::class, 'status_update'])->name('floors.status_update');
});
