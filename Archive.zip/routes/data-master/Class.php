<?php

use App\Http\Controllers\DataMaster\ClassController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('classes', [ClassController::class, 'data'])->name('classes.data');

    Route::post('classes', [ClassController::class, 'store'])->name('classes.store');

    Route::get('classes/{id}', [ClassController::class, 'show'])->name('classes.show');

    Route::put('classes/{id}', [ClassController::class, 'update'])->name('classes.update');

    Route::delete('classes/{id}', [ClassController::class, 'destroy'])->name('classes.delete');

    Route::put('classes/{id}/status', [ClassController::class, 'status_update'])->name('classes.status_update');
});
