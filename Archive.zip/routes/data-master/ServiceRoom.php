<?php

use App\Http\Controllers\DataMaster\ServiceRoomController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('service-rooms', [ServiceRoomController::class, 'data'])->name('service-rooms.data');

    Route::post('service-rooms', [ServiceRoomController::class, 'store'])->name('service-rooms.store');

    Route::get('service-rooms/{id}', [ServiceRoomController::class, 'show'])->name('service-rooms.show');

    Route::put('service-rooms/{id}', [ServiceRoomController::class, 'update'])->name('service-rooms.update');

    Route::delete('service-rooms/{id}', [ServiceRoomController::class, 'destroy'])->name('service-rooms.delete');

    Route::put('service-rooms/status-update/{id}', [ServiceRoomController::class, 'status_update'])->name('service-rooms.status_update');
});