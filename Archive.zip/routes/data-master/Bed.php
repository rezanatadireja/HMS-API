<?php

use App\Http\Controllers\DataMaster\BedController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('beds', [BedController::class, 'data'])->name('beds.data');

    Route::post('beds', [BedController::class, 'store'])->name('beds.store');

    Route::get('beds/{id}', [BedController::class, 'show'])->name('beds.show');

    Route::put('beds/{id}', [BedController::class, 'update'])->name('beds.update');

    Route::delete('beds/{id}', [BedController::class, 'destroy'])->name('beds.delete');

    Route::put('beds/status-update/{id}', [BedController::class, 'status_update'])->name('beds.status_update');
});