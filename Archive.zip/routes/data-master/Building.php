<?php

use App\Http\Controllers\DataMaster\BuildingController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('buildings', [BuildingController::class, 'data'])->name('buildings.data');

    Route::post('buildings', [BuildingController::class, 'store'])->name('buildings.store');

    Route::get('buildings/{id}', [BuildingController::class, 'show'])->name('buildings.show');

    Route::put('buildings/{id}', [BuildingController::class, 'update'])->name('buildings.update');

    Route::delete('buildings/{id}', [BuildingController::class, 'destroy'])->name('buildings.delete');

    Route::put('buildings/{id}/status', [BuildingController::class, 'status_update'])->name('buildings.status_update');
});
