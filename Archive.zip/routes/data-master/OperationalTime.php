<?php

use App\Http\Controllers\DataMaster\OperationalTimeController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('operational-times', [OperationalTimeController::class, 'data'])->name('operational-times.data');

    Route::post('operational-times', [OperationalTimeController::class, 'store'])->name('operational-times.store');

    Route::get('operational-times/{id}', [OperationalTimeController::class, 'show'])->name('operational-times.show');

    Route::put('operational-times/{id}', [OperationalTimeController::class, 'update'])->name('operational-times.update');

    Route::delete('operational-times/{id}', [OperationalTimeController::class, 'destroy'])->name('operational-times.delete');

    Route::put('operational-times/status-update/{id}', [OperationalTimeController::class, 'status_update'])->name('operational-times.status_update');
});