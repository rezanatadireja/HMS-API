<?php

use App\Http\Controllers\DataMaster\ItemController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('items', [ItemController::class, 'data'])->name('items.data');

    Route::post('items', [ItemController::class, 'store'])->name('items.store');

    Route::get('items/{id}', [ItemController::class, 'show'])->name('items.show');

    Route::put('items/{id}', [ItemController::class, 'update'])->name('items.update');

    Route::delete('items/{id}', [ItemController::class, 'destroy'])->name('items.delete');

    Route::put('items/{id}/status', [ItemController::class, 'status_update'])->name('items.status_update');
});
