<?php

use App\Http\Controllers\DataMaster\DepartmentController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('departments', [DepartmentController::class, 'data'])->name('departments.data');

    Route::post('departments', [DepartmentController::class, 'store'])->name('departments.store');

    Route::get('departments/{id}', [DepartmentController::class, 'show'])->name('departments.show');

    Route::put('departments/{id}', [DepartmentController::class, 'update'])->name('departments.update');

    Route::delete('departments/{id}', [DepartmentController::class, 'destroy'])->name('departments.delete');

    Route::put('departments/status-update/{id}', [DepartmentController::class, 'status_update'])->name('departments.status_update');
});