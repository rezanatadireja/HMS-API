<?php

use App\Http\Controllers\DataMaster\ParamedicScheduleDateController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('paramedic-schedule-dates', [ParamedicScheduleDateController::class, 'data'])->name('paramedic-schedule-dates.data');

    Route::post('paramedic-schedule-dates', [ParamedicScheduleDateController::class, 'store'])->name('paramedic-schedule-dates.store');

    Route::get('paramedic-schedule-dates/{id}', [ParamedicScheduleDateController::class, 'show'])->name('paramedic-schedule-dates.show');

    Route::put('paramedic-schedule-dates/{id}', [ParamedicScheduleDateController::class, 'update'])->name('paramedic-schedule-dates.update');

    Route::delete('paramedic-schedule-dates/{id}', [ParamedicScheduleDateController::class, 'destroy'])->name('paramedic-schedule-dates.delete');

    Route::put('paramedic-schedule-dates/status-update/{id}', [ParamedicScheduleDateController::class, 'status_update'])->name('paramedic-schedule-dates.status_update');
});