<?php

use App\Http\Controllers\PermissionController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('permissions/get-by-user/{id}', [PermissionController::class, 'show_permission_by_user'])->name('permissions.showPermissionByUser');

    Route::get('permissions', [App\Http\Controllers\PermissionController::class, 'data'])->name('permissions.data');

    Route::post('permissions', [App\Http\Controllers\PermissionController::class, 'create'])->name('permissions.create');

    Route::get('permissions/{id}', [App\Http\Controllers\PermissionController::class, 'show'])->name('permissions.show');

    Route::put('permissions/{id}', [App\Http\Controllers\PermissionController::class, 'update'])->name('permissions.update');

    Route::delete('permissions/{id}', [App\Http\Controllers\PermissionController::class, 'delete'])->name('permissions.delete');

    Route::post('permissions/generate', [App\Http\Controllers\PermissionController::class, 'generate'])->name('permissions.generate');

    Route::post('permissions/reset', [App\Http\Controllers\PermissionController::class, 'reset'])->name('permissions.reset');
});
