<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('users', [App\Http\Controllers\UserController::class, 'data'])->name('users.data');

    Route::post('users', [App\Http\Controllers\UserController::class, 'create'])->name('users.create');

    Route::get('users/{id}', [App\Http\Controllers\UserController::class, 'show'])->name('users.show');

    Route::put('users/{id}', [App\Http\Controllers\UserController::class, 'update'])->name('users.update');

    Route::delete('users/{id}', [App\Http\Controllers\UserController::class, 'delete'])->name('users.delete');

    Route::put('users/change-password/{id}', [App\Http\Controllers\UserController::class, 'change_password'])->name('users.change-password');
});
