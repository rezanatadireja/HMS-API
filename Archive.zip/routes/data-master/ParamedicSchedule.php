<?php

use App\Http\Controllers\DataMaster\ParamedicScheduleController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('paramedic-schedules', [ParamedicScheduleController::class, 'data'])->name('paramedic-schedules.data');

    Route::post('paramedic-schedules', [ParamedicScheduleController::class, 'store'])->name('paramedic-schedules.store');

    Route::get('paramedic-schedules/{id}', [ParamedicScheduleController::class, 'show'])->name('paramedic-schedules.show');

    Route::put('paramedic-schedules/{id}', [ParamedicScheduleController::class, 'update'])->name('paramedic-schedules.update');

    Route::delete('paramedic-schedules/{id}', [ParamedicScheduleController::class, 'destroy'])->name('paramedic-schedules.delete');

    Route::put('paramedic-schedules/status-update/{id}', [ParamedicScheduleController::class, 'status_update'])->name('paramedic-schedules.status_update');
});