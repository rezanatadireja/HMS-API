<?php

use App\Http\Controllers\DataMaster\LocationController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('locations', [LocationController::class, 'data'])->name('locations.data');

    Route::post('locations', [LocationController::class, 'store'])->name('locations.store');

    Route::get('locations/{id}', [LocationController::class, 'show'])->name('locations.show');

    Route::put('locations/{id}', [LocationController::class, 'update'])->name('locations.update');

    Route::delete('locations/{id}', [LocationController::class, 'destroy'])->name('locations.delete');

    Route::put('locations/{id}/status', [LocationController::class, 'status_update'])->name('locations.status_update');
});