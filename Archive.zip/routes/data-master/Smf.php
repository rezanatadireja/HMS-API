<?php

use App\Http\Controllers\DataMaster\SmfController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('smfs', [SmfController::class, 'data'])->name('smfs.data');

    Route::post('smfs', [SmfController::class, 'store'])->name('smfs.store');

    Route::get('smfs/{id}', [SmfController::class, 'show'])->name('smfs.show');

    Route::put('smfs/{id}', [SmfController::class, 'update'])->name('smfs.update');

    Route::delete('smfs/{id}', [SmfController::class, 'destroy'])->name('smfs.delete');

    Route::put('smfs/{id}/status', [SmfController::class, 'status_update'])->name('smfs.status_update');
});
