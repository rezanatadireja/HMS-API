<?php

use App\Http\Controllers\MenuManagementController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('menu-managements', [App\Http\Controllers\MenuManagementController::class, 'data'])->name('menu-managements.data');

    Route::post('menu-managements', [App\Http\Controllers\MenuManagementController::class, 'create'])->name('menu-managements.create');

    Route::get('menu-managements/{id}', [App\Http\Controllers\MenuManagementController::class, 'show'])->name('menu-managements.show');

    Route::put('menu-managements/{id}', [App\Http\Controllers\MenuManagementController::class, 'update'])->name('menu-managements.update');

    Route::delete('menu-managements/{id}', [App\Http\Controllers\MenuManagementController::class, 'delete'])->name('menu-managements.delete');

    Route::post('menu-managements/build-menu', [App\Http\Controllers\MenuManagementController::class, 'tree'])->name('menu-managements.build-menu');
});
