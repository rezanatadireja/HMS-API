<?php

use App\Http\Controllers\DataMaster\ItemGroupController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('item-groups', [ItemGroupController::class, 'data'])->name('item-groups.data');

    Route::post('item-groups', [ItemGroupController::class, 'store'])->name('item-groups.store');

    Route::get('item-groups/{id}', [ItemGroupController::class, 'show'])->name('item-groups.show');

    Route::put('item-groups/{id}', [ItemGroupController::class, 'update'])->name('item-groups.update');

    Route::delete('item-groups/{id}', [ItemGroupController::class, 'destroy'])->name('item-groups.delete');

    Route::put('item-groups/{id}/status', [ItemGroupController::class, 'status_update'])->name('item-groups.status_update');
});
