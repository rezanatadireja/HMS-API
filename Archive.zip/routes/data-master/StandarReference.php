<?php

use App\Http\Controllers\DataMaster\StandarReferenceController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('standar-references', [App\Http\Controllers\DataMaster\StandarReferenceController::class, 'data'])->name('standar-references.data');

    Route::post('standar-references', [App\Http\Controllers\DataMaster\StandarReferenceController::class, 'store'])->name('standar-references.create');

    Route::get('standar-references/{id}', [App\Http\Controllers\DataMaster\StandarReferenceController::class, 'show'])->name('standar-references.show');

    Route::put('standar-references/{id}', [App\Http\Controllers\DataMaster\StandarReferenceController::class, 'update'])->name('standar-references.update');

    Route::delete('standar-references/{id}', [App\Http\Controllers\DataMaster\StandarReferenceController::class, 'delete'])->name('standar-references.delete');

    Route::put('standar-references/status-update/{id}', [App\Http\Controllers\DataMaster\StandarReferenceController::class, 'status_update'])->name('standar-references.status-update');
});
