<?php

use App\Http\Controllers\DataMaster\AppParameterController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('app-parameters', [AppParameterController::class, 'data'])->name('app-parameters.data');

    Route::post('app-parameters', [AppParameterController::class, 'store'])->name('app-parameters.store');

    Route::get('app-parameters/{id}', [AppParameterController::class, 'show'])->name('app-parameters.show');

    Route::put('app-parameters/{id}', [AppParameterController::class, 'update'])->name('app-parameters.update');

    Route::delete('app-parameters/{id}', [AppParameterController::class, 'destroy'])->name('app-parameters.delete');
});
