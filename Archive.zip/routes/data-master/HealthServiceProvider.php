<?php

use App\Http\Controllers\DataMaster\HealthServiceProviderController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('health-service-providers', [HealthServiceProviderController::class, 'data'])->name('health-service-providers.data');

    Route::post('health-service-providers', [HealthServiceProviderController::class, 'store'])->name('health-service-providers.store');

    Route::get('health-service-providers/{id}', [HealthServiceProviderController::class, 'show'])->name('health-service-providers.show');

    Route::put('health-service-providers/{id}', [HealthServiceProviderController::class, 'update'])->name('health-service-providers.update');

    Route::delete('health-service-providers/{id}', [HealthServiceProviderController::class, 'destroy'])->name('health-service-providers.delete');

    Route::put('health-service-providers/{id}/status', [HealthServiceProviderController::class, 'status_update'])->name('health-service-providers.status_update');
});
