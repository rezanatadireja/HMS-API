<?php

use App\Http\Controllers\DataMaster\ParamedicController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('paramedics', [ParamedicController::class, 'data'])->name('paramedics.data');

    Route::post('paramedics', [ParamedicController::class, 'store'])->name('paramedics.store');

    Route::get('paramedics/{id}', [ParamedicController::class, 'show'])->name('paramedics.show');

    Route::put('paramedics/{id}', [ParamedicController::class, 'update'])->name('paramedics.update');

    Route::delete('paramedics/{id}', [ParamedicController::class, 'destroy'])->name('paramedics.delete');

    Route::put('paramedics/status-update/{id}', [ParamedicController::class, 'status_update'])->name('paramedics.status_update');
});