<?php

use App\Http\Controllers\RoleController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('roles', [App\Http\Controllers\RoleController::class, 'data'])->name('roles.data');

    Route::post('roles', [App\Http\Controllers\RoleController::class, 'create'])->name('roles.create');

    Route::get('roles/{id}', [App\Http\Controllers\RoleController::class, 'show'])->name('roles.show');

    Route::put('roles/{id}', [App\Http\Controllers\RoleController::class, 'update'])->name('roles.update');

    Route::delete('roles/{id}', [App\Http\Controllers\RoleController::class, 'delete'])->name('roles.delete');
});
