<?php

use App\Http\Controllers\DataMaster\GuarantorConntroller;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('guarantors', [GuarantorConntroller::class, 'data'])->name('guarantors.data');

    Route::post('guarantors', [GuarantorConntroller::class, 'store'])->name('guarantors.store');

    Route::get('guarantors/{id}', [GuarantorConntroller::class, 'show'])->name('guarantors.show');

    Route::put('guarantors/{id}', [GuarantorConntroller::class, 'update'])->name('guarantors.update');

    Route::delete('guarantors/{id}', [GuarantorConntroller::class, 'destroy'])->name('guarantors.delete');

    Route::put('guarantors/{id}/status', [GuarantorConntroller::class, 'status_update'])->name('guarantors.status_update');
});
