<?php

use App\Http\Controllers\DataMaster\DepartmentTypeController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('department-types', [DepartmentTypeController::class, 'data'])->name('department-types.data');

    Route::post('department-types', [DepartmentTypeController::class, 'store'])->name('department-types.store');

    Route::get('department-types/{id}', [DepartmentTypeController::class, 'show'])->name('department-types.show');

    Route::put('department-types/{id}', [DepartmentTypeController::class, 'update'])->name('department-types.update');

    Route::delete('department-types/{id}', [DepartmentTypeController::class, 'destroy'])->name('department-types.delete');

    Route::put('department-types/{id}/status', [DepartmentTypeController::class, 'status_update'])->name('department-types.status_update');
});
