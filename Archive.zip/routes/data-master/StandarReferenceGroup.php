<?php

use App\Http\Controllers\DataMaster\StandarReferenceGroupController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => ['jwt.verify']], function () {

    Route::get('standar-reference-groups', [App\Http\Controllers\DataMaster\StandarReferenceGroupController::class, 'data'])->name('standar-reference-groups.data');

    Route::post('standar-reference-groups', [App\Http\Controllers\DataMaster\StandarReferenceGroupController::class, 'store'])->name('standar-reference-groups.create');

    Route::get('standar-reference-groups/{id}', [App\Http\Controllers\DataMaster\StandarReferenceGroupController::class, 'show'])->name('standar-reference-groups.show');

    Route::put('standar-reference-groups/{id}', [App\Http\Controllers\DataMaster\StandarReferenceGroupController::class, 'update'])->name('standar-reference-groups.update');

    Route::delete('standar-reference-groups/{id}', [App\Http\Controllers\DataMaster\StandarReferenceGroupController::class, 'delete'])->name('standar-reference-groups.delete');

    Route::put('standar-reference-groups/status-update/{id}', [App\Http\Controllers\DataMaster\StandarReferenceGroupController::class, 'status_update'])->name('standar-reference-groups.status-update');

});
