<?php

namespace App\Interfaces\DataMaster;

interface MenuManagementInterface
{
    public function data($request);
    public function show($id);
    public function store($request);
    public function update($id, $request);
    public function delete($id);
    public function tree();
}
