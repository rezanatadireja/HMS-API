<?php

namespace App\Interfaces\DataMaster;

interface ParamedicScheduleInterface
{
    public function data($request);
    public function findById($id);
    public function store($request);
    public function update($request, $id);
    public function delete($id);
    public function status_update($id, $request);
}
