<?php

namespace App\Interfaces\UserManagement;

interface PermissionInterface
{
    public function data($request);

    public function create($request);

    public function show($id);

    public function update($request, $id);

	public function delete($id);

    public function show_permission_by_user($id);

    public function generate($request);

    public function reset($request);
}
