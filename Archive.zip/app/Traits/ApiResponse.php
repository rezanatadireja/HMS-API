<?php namespace App\Traits;
/**
 * @author Rio Irmayanto <rio.irmayanto@gmail.com>
 */

use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;
use Validator;

trait ApiResponse
{
    protected function showAll(Collection $collection, $code = 200, $paginate = true)
	{
		if ($collection->isEmpty()) {
			return $this->successResponse(['data' => $collection], $code);
		}

		$transformer = $collection->first()->transformer;

		$collection = $this->sortData($collection);

		if ($paginate) {
			$collection = $this->paginated($collection);
		}

		$collection = $this->transformerData($collection, $transformer);

		return $this->successResponse($collection, $code);
	}
    protected function showOne($data, $code = 200)
	{
		$transformer = $data->transformer;
		$data = $this->transformerData($data, $transformer);

		return $this->successResponse($data, $code);
	}
    protected function showMessage($message, $code)
	{
		return $this->successResponse(['data' => $message], $code);
	}
    protected function sortData(Collection $collection)
	{
		 if (app('request')->has('default_id') && !empty(app('request')->default_id)) {
            $attribute = app('request')->default_id;
            $collection = $collection->sortByDesc(fn($v) => $v['id'] == $attribute);
            return $collection;
        }

		if (app('request')->has('sort_by') && !empty(app('request')->sort_by)) {
			$attribute = app('request')->sort_by;

			$collection = $collection->sortBy($attribute);

		} else {
			$collection = $collection->sortByDesc('created_at');
		}

		return $collection;
	}
    public function paginated(Collection $collection)
	{
		$rules = [
			'per_page' => 'integer|min:3|max:50'
		];

		Validator::validate(app('request')->all(), $rules);

		$per_page = 5;
		$page = LengthAwarePaginator::resolveCurrentPage();

		if (app('request')->has('per_page') && !empty(app('request')->per_page)) {
			$per_page = (int) app('request')->per_page;
		}

		$results = $collection->slice(($page - 1) * $per_page, $per_page)->values();
		$paginated = new LengthAwarePaginator($results, $collection->count(), $per_page, Paginator::resolveCurrentPage(), [
			'path' => Paginator::resolveCurrentPath()
		]);

		$paginated->appends(app('request')->all());

		return $paginated;
	}

	/**
	 * @param mixed  $collection Collection.
	 * @param mixed  $transformer Class Transformer.
	 * @return mixed
	 */
	protected function transformerData($data, $transformer)
	{
		$transformation = fractal($data, new $transformer);
        return $transformation->toArray();
	}
	protected function successResponse($data = [], $metadataCode = 200, $code = 200)
	{
        return response()->json([
			'metadata'=> [
                'code'=>$metadataCode,
                'message'=>'Ok'
            ],
			'response' => $data,
		], $code);
	}

	protected function errorResponse($message, $code)
	{
		return response()->json([
			'metadata'=> [
                'code'=>$code,
                'message'=>$message
            ]
		], $code);

	}
}
