<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class ItemRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        switch ($this->method()) {
            case 'POST':
                return [
                    'item_group_id' => 'required',
                    'asset_group_id' => 'nullable',
                    'ref_item_type' => 'nullable',
                    'ref_billing_group' => 'nullable',
                    'ref_item_category' => 'nullable',
                    'ref_item_sub_group' => 'nullable',
                    'name' => 'required|unique:items,name',
                    'is_item_production' => 'nullable',
                    'barcode' => 'nullable',
                    'image' => 'nullable',
                    'validity_period_from' => 'nullable',
                    'validity_period_to' => 'nullable',
                    'is_asset' => 'nullable',
                    'is_delegation_to_nurse' => 'nullable',
                    'is_new_upload' => 'nullable',
                    'status' => 'required',
                    'notes' => 'nullable',
                ];

            case 'PUT':
                return [
                    'item_group_id' => 'required',
                    'asset_group_id' => 'nullable',
                    'ref_item_type' => 'nullable',
                    'ref_billing_group' => 'nullable',
                    'ref_item_category' => 'nullable',
                    'ref_item_sub_group' => 'nullable',
                    'name' => 'required|unique:items,name,' . $this->id,
                    'is_item_production' => 'nullable',
                    'barcode' => 'nullable',
                    'image' => 'nullable',
                    'validity_period_from' => 'nullable',
                    'validity_period_to' => 'nullable',
                    'is_asset' => 'nullable',
                    'is_delegation_to_nurse' => 'nullable',
                    'is_new_upload' => 'nullable',
                    'status' => 'required',
                    'notes' => 'nullable',
                ];
            default:
                return [];
        }
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Kolom Nama Harus Diisi',
            'name.unique' => 'Kolom Nama Sudah Ada, Silahkan Periksa Kembali',
            'item_group_id.required' => 'Kolom Item Group Harus Diisi',
            'status.required' => 'Kolom Status Harus Diisi',
        ];
    }
}
