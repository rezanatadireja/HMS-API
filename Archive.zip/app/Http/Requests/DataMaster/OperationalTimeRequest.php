<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class OperationalTimeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required',
            'start_time_1' => 'required|max:5',
            'end_time_1' => 'required|max:5',
            'start_time_2' => 'required|max:5',
            'end_time_2' => 'required|max:5',
            'start_time_3' => 'required|max:5',
            'end_time_3' => 'required|max:5',
            'start_time_4' => 'required|max:5',
            'end_time_4' => 'required|max:5',
            'start_time_5' => 'required|max:5',
            'end_time_5' => 'required|max:5',
            'time_back_color' => 'required',
            'owner_user_id' => 'nullable|uuid',
            'status' => 'required|integer'
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'kolom name harus di isi',
            'start_time_1.required' => 'kolom start time 1 harus di isi',
            'start_time_1.max' => 'kolom start time 1 tidak boleh lebih dari 5 karakter',
            'end_time_1.required' => 'kolom end time 1 harus di isi',
            'end_time_1.max' => 'kolom end time 1 tidak boleh lebih dari 5 karakter',
            'start_time_2.required' => 'kolom start time 2 harus di isi',
            'start_time_2.max' => 'kolom start time 2 tidak boleh lebih dari 5 karakter',
            'end_time_2.required' => 'kolom end time 2 harus di isi',
            'end_time_2.max' => 'kolom end time 2 tidak boleh lebih dari 5 karakter',
            'start_time_3.required' => 'kolom start time 3 harus di isi',
            'start_time_3.max' => 'kolom start time 3 tidak boleh lebih dari 5 karakter',
            'end_time_3.required' => 'kolom end time 3 harus di isi',
            'end_time_3.max' => 'kolom end time 3 tidak boleh lebih dari 5 karakter',
            'start_time_4.required' => 'kolom start time 4 harus di isi',
            'start_time_4.max' => 'kolom start time 4 tidak boleh lebih dari 5 karakter',
            'end_time_4.required' => 'kolom end time 4 harus di isi',
            'end_time_4.max' => 'kolom end time 4 tidak boleh lebih dari 5 karakter',
            'start_time_5.required' => 'kolom start time 5 harus di isi',
            'start_time_5.max' => 'kolom start time 5 tidak boleh lebih dari 5 karakter',
            'end_time_5.required' => 'kolom end time 5 harus di isi',
            'end_time_5.max' => 'kolom end time 5 tidak boleh lebih dari 5 karakter',
            'time_back_color.required' => 'kolom time back color harus di isi',
            'owner_user_id.uuid' => 'type data time back color harus uuid',
            'time_back_color.required' => 'kolom time back color harus di isi',
            'time_back_color.integer' => 'type data time back color harus angka'
        ];
    }
}