<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class DepartmentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'department_type_id' => 'required|uuid',
            'parent_id' => 'nullable|uuid',
            'building_id' => 'required|uuid',
            'floor_id' => 'required|uuid',
            'name' => ['required', 'string', Rule::unique('departments')->ignore($this->id)],
            'short_name' => ['required', 'string', Rule::unique('departments')->ignore($this->id)],
            'code' => ['required', 'string', Rule::unique('departments')->ignore($this->id)],
            'is_using_job_order' => 'required|integer',
            'is_patient_transaction' => 'required|integer',
            'is_dispensary_unit' => 'required|integer',
            'is_purchasing_unit' => 'required|integer',
            'status' => 'required|integer'
        ];
    }

    public function messages(): array
    {
        return [
            'department_type_id.required' => 'kolom department type id harus di isi',
            'department_type_id.uuid' => 'type kolom department type id harus uuid',
            'parent_id.uuid' => 'type kolom parent id harus uuid',
            'building_id.required' => 'kolom building id harus di isi',
            'building_id.uuid' => 'type kolom building id harus uuid',
            'floor_id.required' => 'kolom floor id harus di isi',
            'floor_id.uuid' => 'type kolom floor id harus uuid',
            'name.required' => 'kolom name harus harus di isi',
            'name.unique' => 'kolom name sudah pernah digunakan',
            'short_name.required' => 'kolom short name harus di isi',
            'short_name.unique' => 'kolom short name sudah pernah digunakan',
            'code.required' => 'kolom code harus di isi',
            'code.unique' => 'kolom code sudah pernah digunakan',
            'is_using_job_order.required' => 'kolom is using job order harus di isi',
            'is_using_job_order.integer' => 'kolom is using job order harus di isi angka',
            'is_patient_transaction.required' => 'kolom is patient transaction harus di isi',
            'is_patient_transaction.integer' => 'kolom is patient transaction harus di isi angka',
            'is_dispensary_unit.required' => 'kolom is dispensary unit harus di isi',
            'is_dispensary_unit.integer' => 'kolom is dispensary unit harus di isi angka',
            'is_purchasing_unit.required' => 'kolom is purchasing harus di isi',
            'is_purchasing_unit.integer' => 'kolom is purchasing harus di isi angka',
            'status.required' => 'kolom status harus di isi',
            'status.integer' => 'kolom status harus di isi angka'
        ];
    }
}
