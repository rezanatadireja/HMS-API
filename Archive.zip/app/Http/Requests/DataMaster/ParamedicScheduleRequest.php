<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class ParamedicScheduleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'paramedic_id' => 'required|uuid',
            'service_unit_id' => 'required|uuid',
            'period_year' => 'required|string',
            'exam_duration' => 'nullable|uuid',
            'notes' => 'required|string',
            'quota' => 'nullable|integer',
            'quota_online' => 'nullable|integer',
            'quota_bpjs' => 'nullable|integer',
            'quota_bpjs_online' => 'nullable|integer',
            'owner_user_id' => 'nullable|uuid'
        ];
    }

    public function messages(): array
    {
        return [
            'paramedic_id.required' => 'kolom paramedic id harus di isi',
            'paramedic_id.uuid' => 'type data kolom paramedic id harus uuid',
            'service_unit_id.required' => 'kolom service unit id harus di isi',
            'service_unit_id.uuid' => 'type data kolom service unit id harus uuid',
            'period_year.required' => 'kolom periode year harus di isi',
            'notes.required' => 'kolom notes harus di isi',
            'quota.integer' => 'kolom quota harus angka',
            'quota_online.integer' => 'kolom quota online harus angka',
            'quota_bpjs.integer' => 'kolom quota bpjs harus angka',
            'quota_bpjs_online.integer' => 'kolom quota bpjs online harus angka',
            'owner_user_id.uuid' => 'type data kolom owner user id harus uuid'
        ];
    }
}