<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class ParamedicScheduleDateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'service_unit_id' => 'required|uuid',
            'paramedic_id' => 'required|uuid',
            'operational_time_id' => 'required|uuid',
            'period_year' => 'required',
            'schedule_date' => 'required',
            'is_closed_time_1' => 'nullable|integer',
            'losed_time_1' => 'nullable|integer',
            'closed_time_1_by_user_id' => 'nullable|integer',
            'is_closed_time_2' => 'nullable|integer',
            'losed_time_2' => 'nullable|integer',
            'closed_time_2_by_user_id' => 'nullable|integer',
            'is_closed_time_3' => 'nullable|integer',
            'losed_time_3' => 'nullable|integer',
            'closed_time_3_by_user_id' => 'nullable|integer',
            'is_closed_time_4' => 'nullable|integer',
            'losed_time_4' => 'nullable|integer',
            'closed_time_4_by_user_id' => 'nullable|integer',
            'is_closed_time_5' => 'nullable|integer',
            'losed_time_5' => 'nullable|integer',
            'closed_time_5_by_user_id' => 'nullable|integer',
            'is_ipr' => 'nullable|integer',
            'is_opr' => 'nullable|integer',
            'is_emr' => 'nullable|integer',
            'period_month' => 'nullable',
            'add_quota' => 'nullable|uuid',
            'add_quota_online' => 'nullable|uuid',
            'add_quota_bpjs' => 'nullable|uuid',
            'add_quota_bpjs_online' => 'nullable|uuid',
            'owner_user_id' => 'nullable|uuid'
        ];
    }

    public function messages(): array
    {
        return [
            'service_unit_id.required' => 'kolom service unit id harus di isi',
            'service_unit_id.uuid' => 'type data kolom service unit id harus uuid',
            'paramedic_id.required' => 'kolom paramedic id harus di isi',
            'paramedic_id.uuid' => 'type data kolom paramedic id harus uuid',
            'operational_time_id.required' => 'kolom operational time harus di isi',
            'operational_time_id.uuid' => 'type data kolom operational time id harus uuid',
            'period_year.required' => 'kolom periode year harus di isi',
            'schedule_date.required' => 'kolom schedule date harus di isi',
            'is_closed_time_1.integer' => 'kolom is closed time harus di isi angka',
            'losed_time_1.integer' => 'kolom losed time 1 harus di isi angka',
            'closed_time_1_by_user_id.integer' => 'kolom closed time 1 by user id harus di isi angka',
            'is_closed_time_2.integer' => 'kolom is closed time 2 harus di isi angka',
            'losed_time_2.integer' => 'kolom losed time 2 harus di isi angka',
            'closed_time_2_by_user_id.integer' => 'kolom closed time 2 by user id harus di isi angka',
            'is_closed_time_3.integer' => 'kolom is closed time 3 harus di isi angka',
            'losed_time_3.integer' => 'kolom losed time 3 harus di isi angka',
            'closed_time_3_by_user_id.integer' => 'kolom closed time 3 by userid harus di isi angka',
            'is_closed_time_4.integer' => 'kolom is closed time 4 harus di isi angka',
            'losed_time_4.integer' => 'kolom losed time 4 harus di isi angka',
            'closed_time_4_by_user_id.integer' => 'kolom closed time 4 by user id harus di isi angka',
            'is_closed_time_5.integer' => 'kolom is closed time 5 harus di isi angka',
            'losed_time_5.integer' => 'kolom losed time 5 harus di isi angka',
            'closed_time_5_by_user_id.integer' => 'kolom closed time 5 by user id harus di isi angka',
            'is_ipr.integer' => 'kolom is ipr harus di isi angka',
            'is_opr.integer' => 'kolom is opr harus di isi angka',
            'is_emr.integer' => 'kolom is emr harus di isi angka',
            'add_quota.integer' => 'kolom is_emr harus di isi angka',
            'add_quota_online.integer' => 'kolom is_emr harus di isi angka',
            'add_quota_bpjs.integer' => 'kolom is_emr harus di isi angka',
            'add_quota_bpjs_online.integer' => 'kolom is_emr harus di isi angka',
            'owner_user_id.uuid' => 'type data kolom owner user harus uuid',

        ];
    }
}