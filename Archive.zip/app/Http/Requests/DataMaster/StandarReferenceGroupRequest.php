<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class StandarReferenceGroupRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|unique:standar_reference_groups,name',
            'code' => 'required|unique:standar_reference_groups,code',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Kolom Nama wajib diisi',
            'name.unique' => 'Kolom Nama Sudah Ada, Silahlan Cek Kembali.',
            'code.required' => 'Kolom Kode Standar Reference wajib diisi',
            'code.unique' => 'Kolom Kode Sudah Ada, Silahlan Cek Kembali.',
        ];
    }
}
