<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class ItemGroupRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        switch ($this->method()) {
            case 'POST':
                return [
                    'ref_item_type' => 'nullable',
                    'name' => 'required|unique:item_groups,name',
                    'cito_value' => 'required|numeric|between:0,999999.99',
                    'is_cito_in_patient' => 'nullable',
                    'initial' => 'nullable|max:8',
                    'restriction_user_type' => 'nullable',
                    'status' => 'required',
                ];

            case 'PUT':
                return [
                    'ref_item_type' => 'nullable',
                    'name' => 'required|unique:item_groups,name,' . $this->id,
                    'cito_value' => 'required|numeric|between:0,999999.99',
                    'is_cito_in_patient' => 'nullable',
                    'initial' => 'nullable|max:8',
                    'restriction_user_type' => 'nullable|max:150',
                    'status' => 'required',
                ];
            default:
                return [];
        }
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Kolom Nama Harus Diisi',
            'name.unique' => 'Kolom Nama Sudah Ada, Silahkan Periksa Kembali',
            'cito_value.required' => 'Kolom Cito Value Harus Diisi',
            'cito_value.between' => 'Kolom Cito Value Tidak Valid, Silahkan Periksa Kembali',
            'initial.max' => 'Kolom Inisial Maksimal 8 Karakter, Silahkan Periksa Kembali',
            'restriction_user_type.max' => 'Kolom Tipe User Maksimal 150 Karakter, Silahkan Periksa Kembali',
            'status.required' => 'Kolom Status Harus Diisi',
        ];
    }
}
