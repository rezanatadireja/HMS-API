<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class SmfRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        switch ($this->method()) {
            case 'POST':
                return [
                    'ref_paramedic_fee_cash_type' => 'nullable',
                    'ref_assesment_type' => 'nullable',
                    'name' => 'required|unique:smfs,name',
                    'status' => 'required'
                ];
            case 'PUT':
                return [
                    'ref_paramedic_fee_cash_type' => 'nullable',
                    'ref_assesment_type' => 'nullable',
                    'name' => 'required|unique:smfs,name,' . $this->id,
                    'status' => 'required'
                ];
            default:
                break;
        }
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Kolom Nama Tidak Boleh Kosong',
            'name.unique' => 'Kolom Nama Sudah Ada, Silahkan Periksa Kembali',
            'status.required' => 'Kolom Status Tidak Boleh Kosong',
        ];
    }
}
