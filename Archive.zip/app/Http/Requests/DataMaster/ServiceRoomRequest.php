<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class ServiceRoomRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'department_id' => 'required|uuid',
            'floor_id' => 'required|uuid',
            'ref_gender_type' => 'nullable|uuid',
            'name' => 'required|string',
            'is_operation_room' => 'nullable|integer',
            'is_bpjs' => 'nullable|integer',
            'is_isolation_room' => 'nullable|integer',
            'is_negative_pressure_room' => 'nullable|integer',
            'is_pandemic_room' => 'nullable|integer',
            'is_ventilator' => 'nullable|integer',
            'notes' => 'required',
            'status' => 'required',
            'owner_user_id' => 'nullable|uuid'
        ];
    }

    public function messages(): array
    {
        return [
            'department_id.required' => 'kolom department id harus di isi',
            'department_id.uuid' => 'type data department id harus uuid',
            'floor_id.required' => 'kolom floor id harus di isi',
            'floor_id.uuid' => 'type data kolom floor id harus uuid',
            'ref_gender_type.uuid' => 'type data kolom ref gender type harus uuid',
            'name.required' => 'kolom name harus di isi',
            'is_operation_room.integer' => 'kolom is operation room harus di isi angka',
            'is_bpjs.integer' => 'kolom is bpjs harus di isi angka',
            'is_isolation_room.integer' => 'kolom is isolation room harus di isi angka',
            'is_negative_pressure_room.integer' => 'kolom is negative pressure room harus di isi angka',
            'is_pandemic_room.integer' => 'kolom is pandemic room harus di isi angka',
            'is_ventilator.integer' => 'kolom is ventilator harus di isi angka',
            'notes.required' => 'kolom notes harus di isi',
            'status.required' => 'kolom status harus di isi',
            'owner_user_id.uuid' => 'type data kolom owner user id harus uuid'
        ];
    }
}