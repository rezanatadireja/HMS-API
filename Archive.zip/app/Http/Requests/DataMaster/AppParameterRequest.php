<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class AppParameterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|unique:app_parameters,name',
            'value' => 'nullable|string',
            'type' => 'nullable',
            'is_used_by_system' => 'nullable',
            'message' => 'nullable',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Kolom Nama Tidak Boleh Kosong.',
            'name.unique' => 'Nama Sudah Ada, Silahkan Gunakan Nama Yang Lain.',
        ];
    }
}
