<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class ClassRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        switch ($this->method()) {
            case 'POST':
                return [
                    'bpjs_class_id' => 'nullable',
                    'ref_class_id' => 'nullable',
                    'name' => 'required|unique:classses',
                    'short_name' => 'required|unique:classses',
                    'margin_percentage' => 'required',
                    'margin_2_percentage' => 'required',
                    'deposit_ammount' => 'required',
                    'is_in_patient_class' => 'required',
                    'is_tariff_class' => 'required',
                    'class_sequence' => 'required',
                    'status' => 'required'
                ];
            case 'PUT':
                return [
                    'bpjs_class_id' => 'nullable',
                    'ref_class_id' => 'nullable',
                    'name' => 'required|unique:classses,name,' . $this->id,
                    'short_name' => 'required|unique:classses,short_name,' . $this->id,
                    'margin_percentage' => 'required',
                    'margin_2_percentage' => 'required',
                    'deposit_ammount' => 'required',
                    'is_in_patient_class' => 'required',
                    'is_tariff_class' => 'required',
                    'class_sequence' => 'required',
                    'status' => 'required'
                ];
            default:
                return [];
        }
    }

    public function messages()
    {
        return [
            'name.required' => 'Kolom Nama wajib diisi',
            'name.unique' => 'Kolom Nama sudah ada, silahkan periksa kembali.',
            'numeric' => ':attribute harus berupa angka'
        ];
    }
}
