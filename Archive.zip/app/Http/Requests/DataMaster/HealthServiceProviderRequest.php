<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class HealthServiceProviderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        switch ($this->method()) {
            case 'POST':
                return [
                    'teritory_id' => 'nullable',
                    'name' => 'required|unique:health_service_providers,name',
                    'address_line_1' => 'nullable',
                    'address_line_2' => 'nullable',
                    'zip_code' => 'nullable',
                    'phone_no' => 'nullable',
                    'fax_no' => 'nullable',
                    'code' => 'nullable',
                    'email_address' => 'nullable',
                    'website' => 'nullable',
                    'npwp' => 'nullable',
                    'hospital_type' => 'nullable',
                    'additional_info' => 'nullable',
                    'logo' => 'nullable',
                ];
            case 'PUT':
                return [
                    'teritory_id' => 'nullable',
                    'name' => 'required|unique:health_service_providers,name,' . $this->id,
                    'address_line_1' => 'nullable',
                    'address_line_2' => 'nullable',
                    'zip_code' => 'nullable',
                    'phone_no' => 'nullable',
                    'fax_no' => 'nullable',
                    'code' => 'nullable',
                    'email_address' => 'nullable',
                    'website' => 'nullable',
                    'npwp' => 'nullable',
                    'hospital_type' => 'nullable',
                    'additional_info' => 'nullable',
                    'logo' => 'nullable',
                ];
            default:
                return [];
        }
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Kolom Nama Tidak Boleh Kosong.',
            'name.unique' => 'Kolom Nama Sudah Ada, Silahkan Periksa Kembali.',
        ];
    }
}
