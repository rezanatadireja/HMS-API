<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class ParamedicRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'employee_id' => 'required|uuid',
            'ref_paramedic_type' => 'required|uuid',
            'ref_paramedic_status' => 'required|uuid',
            'ref_speciality' => 'required|uuid',
            'name' => 'required|string',
            'initial' => 'required|max:5',
            'date_of_birth' => 'required',
            'notes' => 'required|string',
            'status' => 'required|integer',
            'owner_user_id' => 'nullable|uuid'
        ];
    }

    public function messages(): array
    {
        return [
            'employee_id.required' => 'kolom employee harus di isi',
            'employee_id.uuid' => 'type data kolom employee harus uuid',
            'ref_paramedic_type.required' => 'kolom ref paramedic type harus di isi',
            'ref_paramedic_type.uuid' => 'type data kolom ref paramedic type harus uuid',
            'ref_paramedic_status.required' => 'kolom ref paramedic status harus di isi',
            'ref_paramedic_status.uuid' => 'type data kolom ref paramedic status uuid',
            'ref_speciality.required' => 'kolom ref speciality harus di isi',
            'ref_speciality.uuid' => 'type data kolom ref speciality harud uuid',
            'name.required' => 'kolomm name harus di isi',
            'initial.required' => 'kolom initial harus di isi',
            'initial.max' => 'kolom initial maksimal 5 karakter',
            'date_of_birth.required' => 'kolom date of birth harus di isi',
            'notes.required' => 'kolom notes harus di isi',
            'status.required' => 'kolom status harus di isi',
            'status.integer' => 'type data kolom status harus angka',
            'owner_user_id.uuid' => 'type data kolom status harus uuid'
        ];
    }
}
