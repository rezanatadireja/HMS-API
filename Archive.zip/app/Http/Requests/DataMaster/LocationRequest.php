<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class LocationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'parent_id' => 'nullabled',
            'item_group_id' => 'required|uuid',
            'permit_id' => 'nullabled|uuid',
            'ref_type_of_inventory' => 'nullabled|uuid',
            'ref_stock_group' => 'nullabled|uuid',
            'chart_of_account_id_income' => 'nullabled|uuid',
            'subledger_id_income' => 'nullabled|uuid',
            'chart_of_account_id_inventory' => 'nullabled|uuid',
            'chart_of_account_id_cogs' => 'nullabled|uuid',
            'subledger_id_cogs' => 'nullabled|uuid',
            'chart_of_account_id_sales_return' => 'nullabled|uuid',
            'subledger_id_sales_return' => 'nullabled|uuid',
            'chart_of_account_id_purchase_return' => 'nullabled|uuid',
            'subledger_id_purchase_return' => 'nullabled|uuid',
            'chart_of_account_id_acrual' => 'nullabled|uuid',
            'subledger_id_acrual' => 'nullabled|uuid',
            'chart_of_account_id_discount' => 'nullabled|uuid',
            'subledger_id_discount' => 'nullabled|uuid',
            'chart_of_account_id_cost' => 'nullabled|uuid',
            'subledger_id_cost' => 'nullabled|uuid',
            'name' => 'required',
            'short_name' => 'required',
            'is_header' => 'required',
            'is_hold_for_transaction' => 'required',
            'is_allowed_to_stock_goods' => 'required',
            'is_consignment' => 'required',
            'is_validate_max_value_on_dist_req_for_ipm' => 'required',
            'is_validate_max_value_on_dist_req_for_ipnm' => 'required',
            'is_validate_max_value_on_dist_req_for_ik' => 'required',
            'is_validate_max_value_on_purc_req_for_ipm' => 'required',
            'is_validate_max_value_on_purc_req_for_ipnm' => 'required',
            'is_validate_max_value_on_purc_req_for_ik' => 'required',
            'last_hold_for_transaction_date_time' => 'nullabled',
            'last_hold_for_transaction_by_user_id' => 'nullabled',
            'is_auto_update_stock_min_max' => 'required',
            'status' => 'required',
            'owner_user_id' => 'nullabled'
        ];
    }

    public function messages(): array
    {
        return [
            'item_group_id.required' => 'item group id is required',
            'name.required' => 'name is required',
            'short_name.required' => 'short name is required',
            'is_header.required' => 'is header is required',
            'is_hold_for_transaction.required' => 'is hold for transaction is required',
            'is_allowed_to_stock_goods.required' => 'is allowed to stock goods is required',
            'is_consignment.required' => 'is consignment is required',
            'is_validate_max_value_on_dist_req_for_ipm.required' => 'is validate max value on dist req for ipm is required',
            'is_validate_max_value_on_dist_req_for_ipnm.required' => 'is validate max value on dist req for ipnm is required',
            'is_validate_max_value_on_dist_req_for_ik.required' => 'is validate max value on dist req for ik is required',
            'is_validate_max_value_on_purc_req_for_ipm.required' => 'is validate max value on purc req for ipm is required',
            'is_validate_max_value_on_purc_req_for_ipnm.required' => 'is validate max value on purc req for ipnm is required',
            'is_validate_max_value_on_purc_req_for_ik.required' => 'is validate max value on purc req for ik is required',
            'is_auto_update_stock_min_max.required' => 'is auto update stock min max is required',
            'status.required' => 'status is required',
        ];
    }
}