<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class GuarantorRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        switch ($this->method()) {
            case 'POST':
                return [
                    'ref_guarantor_type' => 'required',
                    'ref_business_method' => 'nullable',
                    'ref_guarantor_rule_type' => 'nullable',
                    'ref_payment_type' => 'nullable',
                    'code' => 'required|unique:guarantors,code',
                    'name' => 'required|unique:guarantors,name',
                    'short_name' => 'required',
                    'contract_number' => 'nullable',
                    'contract_start' => 'nullable',
                    'contract_end' => 'nullable',
                    'contract_summary' => 'nullable',
                    'street_name' => 'nullable',
                    'teritory_id' => 'nullable',
                    'country_id' => 'nullable',
                    'zip_code' => 'nullable',
                    'phone_no' => 'required',
                    'fax_no' => 'required',
                    'email' => 'nullable',
                    'mobile_phone_no' => 'required',
                    'is_cover_inpatient' => 'required',
                    'is_cover_outpatient' => 'required',
                    'status' => 'required',
                ];
            case 'PUT':
                return [
                    'ref_guarantor_type' => 'required',
                    'ref_business_method' => 'nullable',
                    'ref_guarantor_rule_type' => 'nullable',
                    'ref_payment_type' => 'nullable',
                    'code' => 'required|unique:guarantors,code,' . $this->id,
                    'name' => 'required|unique:guarantors,name,' . $this->id,
                    'short_name' => 'required',
                    'contract_number' => 'nullable',
                    'contract_start' => 'nullable',
                    'contract_end' => 'nullable',
                    'contract_summary' => 'nullable',
                    'street_name' => 'nullable',
                    'teritory_id' => 'nullable',
                    'country_id' => 'nullable',
                    'zip_code' => 'nullable',
                    'phone_no' => 'required',
                    'fax_no' => 'required',
                    'email' => 'nullable',
                    'mobile_phone_no' => 'required',
                    'is_cover_inpatient' => 'required',
                    'is_cover_outpatient' => 'required',
                    'status' => 'required',
                ];
            default:
                return [];
        }
    }

    public function messages()
    {
        return [
            'name.required' => 'Kolom Nama wajib diisi',
            'name.unique' => 'Kolom Nama sudah ada, silahkan periksa kembali.',
            'code.required' => 'Kolom Kode wajib diisi',
            'code.unique' => 'Kolom Kode sudah ada, silahkan periksa kembali.',
            'ref_guarantor_type.required' => 'Kolom Tipe Penjamin wajib diisi',
            'short_name.required' => 'Kolom Nama Singkat wajib diisi',
            'phone_no.required' => 'Kolom Nomor Telepon wajib diisi',
            'mobile_phone_no.required' => 'Kolom Nomor HP wajib diisi',
            'is_cover_inpatient.required' => 'Kolom Cover Rawat Inap wajib diisi',
            'is_cover_outpatient.required' => 'Kolom Cover Rawat Jalan wajib diisi',
            'status.required' => 'Kolom Status wajib diisi',
        ];
    }
}
