<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class DepartmentTypeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        switch ($this->method()) {
            case 'POST':
                return [
                    'name' => 'required|unique:department_types,name',
                    'code' => 'required|unique:department_types,code',
                    'status' => 'required',
                ];

            case 'PUT':
                return [
                    'name' => 'required|unique:department_types,name,' . $this->id,
                    'code' => 'required|unique:department_types,code,' . $this->id,
                    'status' => 'required',
                ];
            default:
                return [];
        }
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Kolom Nama Harus Diisi',
            'code.required' => 'Kolom Kode Harus Diisi',
            'code.unique' => 'Kode Sudah Ada, Silahkan Periksa Kembali',
            'status.required' => 'Kolom Status Harus Diisi',
        ];
    }
}
