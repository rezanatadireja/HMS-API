<?php

namespace App\Http\Requests\DataMaster;

use Illuminate\Foundation\Http\FormRequest;

class BedRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'room_id' => 'required|uuid',
            'ref_bed_status' => 'required|uuid',
            'old_bed_id' => 'nullable|uuid',
            'default_charge_class_id' => 'nullable|uuid',
            'registration_no' => 'nullable',
            'bed_status_updated_by' => 'required|string',
            'is_temporary' => 'required|integer',
            'is_need_confirmation' => 'required|integer',
            'is_room_in' => 'required|integer',
            'booking_date_time' => 'nullable',
            'is_visible_3rd_party' => 'nullable|integer',
            'notes' => 'nullable',
            'status' => 'required|integer',
            'owner_user_id' => 'nullable|uuid'
        ];
    }

    public function messages(): array
    {
        return [
            'room_id.required' => 'kolom room id harus di isi',
            'room_id.uuid' => 'type data kolom room id harus uuid',
            'ref_bed_status.required' => 'kolom ref bed status harus di isi',
            'ref_bed_status.uuid' => 'type data ref bed status harus uuid',
            'default_charge_class_id.uuid' => 'type data default charge class id harus uuid',
            'bed_status_updated_by.required' => 'kolom bed status update by harus di isi',
            'is_temporary.required' => 'kolom is temporary harus di isi',            
            'is_temporary.integer' => 'type data kolom is temporary harus angka',
            'is_need_confirmation.required' => 'kolom is need confirmation harus di isi',            
            'is_need_confirmation.integer' => 'type data is need confirmation harus angka',
            'is_room_in.required' => 'kolom is room in harus di isi',
            'is_room_in.integer' => 'type data is room in harus angka',
            'is_visible_3rd_party.integer' => 'type data is visible 3rd party harus angka',
            'status.required' => 'kolom status harus di isi',
            'status.integer' => 'type data status harus angka',
            'owner_user_id.uuid' => 'type data status harus uuid'
        ];
    }
}