<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\DepartmentTypeRequest;
use App\Repositories\DataMaster\DepartmentTypeRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class DepartmentTypeController extends Controller
{
    use ApiResponse, Authorizable;

    private $departmentType;

    public function __construct(DepartmentTypeRepository $departmentType)
    {
        $this->departmentType = $departmentType;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->departmentType->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->departmentType->show($id), 200);
    }

    public function store(DepartmentTypeRequest $request)
    {
        $results = $this->departmentType->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(DepartmentTypeRequest $request, $id)
    {
        $results = $this->departmentType->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->departmentType->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->departmentType->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
