<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\LocationRequest;
use App\Repositories\DataMaster\LocationRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    use ApiResponse, Authorizable;

    private $locationRepository;

    public function __construct(LocationRepository $locationRepository)
    {
        $this->locationRepository = $locationRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->locationRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->locationRepository->show($id), 200);
    }

    public function store(LocationRequest $request)
    {
        $results = $this->locationRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(LocationRequest $request, $id)
    {
        $results = $this->locationRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->locationRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->locationRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}