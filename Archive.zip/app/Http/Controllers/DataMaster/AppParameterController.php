<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\AppParameterRequest;
use App\Repositories\DataMaster\AppParameterRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class AppParameterController extends Controller
{
    use ApiResponse, Authorizable;

    private $appParameterRepository;

    public function __construct(AppParameterRepository $appParameterRepository)
    {
        $this->appParameterRepository = $appParameterRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->appParameterRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        $results = $this->appParameterRepository->findById($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }
        return $this->showOne($results['data'], 200);
    }

    public function store(AppParameterRequest $request)
    {
        $results = $this->appParameterRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(AppParameterRequest $request, $id)
    {
        $this->appParameterRepository->findById($id);

        $results = $this->appParameterRepository->update($request, $id);

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->appParameterRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
