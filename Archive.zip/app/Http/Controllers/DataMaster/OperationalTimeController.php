<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\OperationalTimeRequest;
use App\Repositories\DataMaster\OperationalTimeRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class OperationalTimeController extends Controller
{
    use ApiResponse, Authorizable;

    private $operationalTimeRepository;

    public function __construct(OperationalTimeRepository $operationalTimeRepository)
    {
        $this->operationalTimeRepository = $operationalTimeRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->operationalTimeRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        $results = $this->operationalTimeRepository->show($id);
        return $results['status'] === 'error' ? $this->errorResponse($results['message'], 404) 
        : $this->showOne($this->operationalTimeRepository->show($id), 200);
    }

    public function store(OperationalTimeRequest $request)
    {
        $results = $this->operationalTimeRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(OperationalTimeRequest $request, $id)
    {
        $results = $this->operationalTimeRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->operationalTimeRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->operationalTimeRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}