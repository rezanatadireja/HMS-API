<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\ParamedicScheduleRequest;
use App\Repositories\DataMaster\ParamedicScheduleRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class ParamedicScheduleController extends Controller
{
    use ApiResponse, Authorizable;

    private $paramedicScheduleRepository;

    public function __construct(ParamedicScheduleRepository $paramedicScheduleRepository)
    {
        $this->paramedicScheduleRepository = $paramedicScheduleRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->paramedicScheduleRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->paramedicScheduleRepository->show($id), 200);
    }

    public function store(ParamedicScheduleRequest $request)
    {
        $results = $this->paramedicScheduleRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(ParamedicScheduleRequest $request, $id)
    {
        $results = $this->paramedicScheduleRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->paramedicScheduleRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->paramedicScheduleRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}