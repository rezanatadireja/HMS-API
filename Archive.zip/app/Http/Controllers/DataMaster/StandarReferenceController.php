<?php

namespace App\Http\Controllers\DataMaster;

use App\Interfaces\DataMaster\StandarReferenceInterface as StandarReferenceInterface;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Traits\Authorizable;
use App\Traits\ApiResponse;
use App\Models\Periode;


class StandarReferenceController extends Controller
{
    use ApiResponse;
    use Authorizable;

    private $standarReferenceRepository;

    public function __construct(StandarReferenceInterface $standarReferenceRepository)
    {
        $this->standarReferenceRepository = $standarReferenceRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->standarReferenceRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->standarReferenceRepository->show($id), 200);
    }

    public function store(Request $request)
    {
        $results = $this->standarReferenceRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(Request $request, $id)
    {
        $results = $this->standarReferenceRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function delete($id)
    {
        $results = $this->standarReferenceRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->standarReferenceRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
