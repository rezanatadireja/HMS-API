<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\ParamedicScheduleDateRequest;
use App\Repositories\DataMaster\ParamedicScheduleDateRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class ParamedicScheduleDateController extends Controller
{
    use ApiResponse, Authorizable;

    private $paramedicScheduleDateRepository;

    public function __construct(ParamedicScheduleDateRepository $paramedicScheduleDateRepository)
    {
        $this->paramedicScheduleDateRepository = $paramedicScheduleDateRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->paramedicScheduleDateRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->paramedicScheduleDateRepository->show($id), 200);
    }

    public function store(ParamedicScheduleDateRequest $request)
    {
        $results = $this->paramedicScheduleDateRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(ParamedicScheduleDateRequest $request, $id)
    {
        $results = $this->paramedicScheduleDateRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->paramedicScheduleDateRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->paramedicScheduleDateRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}