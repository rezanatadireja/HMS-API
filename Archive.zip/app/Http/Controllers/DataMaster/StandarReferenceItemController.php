<?php

namespace App\Http\Controllers\DataMaster;

use App\Interfaces\DataMaster\StandarReferenceItemInterface as StandarReferenceItemInterface;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Traits\Authorizable;
use App\Traits\ApiResponse;
use App\Models\Periode;


class StandarReferenceItemController extends Controller
{
    use ApiResponse;
    use Authorizable;

    private $standarReferenceItemRepository;

    public function __construct(StandarReferenceItemInterface $standarReferenceItemRepository)
    {
        $this->standarReferenceItemRepository = $standarReferenceItemRepository;
    }

    public function data(Request $request)
    {
        if($request->get('paginate') == "true" ){
            $paginate = true;
        }else{
            $paginate = false;
        }
        return $this->showAll($this->standarReferenceItemRepository->data($request),200,$paginate);
    }

    public function show($id)
	{
        return $this->showOne($this->standarReferenceItemRepository->show($id),200);
	}

    public function store(Request $request)
	{
		$results = $this->standarReferenceItemRepository->store($request);

		if (!$results['status']) {
			return $this->errorResponse($results['message'], 404);
		}

        return $this->successResponse($results['message'], 200);
	}

    public function update(Request $request, $id)
    {
        $results = $this->standarReferenceItemRepository->update($request, $id);

		if (!$results['status']) {
			return $this->errorResponse($results['message'], 404);
		}

        return $this->successResponse($results['message'], 200);
	}

	public function delete($id)
    {
        $results = $this->standarReferenceItemRepository->delete($id);

        if (!$results['status']) {
			return $this->errorResponse($results['message'], 404);
		}

        return $this->successResponse($results['message'], 200);
	}

    public function status_update(Request $request, $id)
    {
        $results = $this->standarReferenceItemRepository->status_update($request, $id);

		if (!$results['status']) {
			return $this->errorResponse($results['message'], 404);
		}

        return $this->successResponse($results['message'], 200);
	}

}
