<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\ParamedicRequest;
use App\Repositories\DataMaster\ParamedicRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class ParamedicController extends Controller
{
    use ApiResponse, Authorizable;

    private $paramedicRepository;

    public function __construct(ParamedicRepository $paramedicRepository)
    {
        $this->paramedicRepository = $paramedicRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->paramedicRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        $results = $this->paramedicRepository->show($id);
        return $results['status'] === 'error' ? $this->errorResponse($results['message'], 404) 
        : $this->showOne($this->paramedicRepository->show($id), 200);
    }

    public function store(ParamedicRequest $request)
    {
        $results = $this->paramedicRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(ParamedicRequest $request, $id)
    {
        $results = $this->paramedicRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->paramedicRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->paramedicRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}