<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\SmfRequest;
use App\Repositories\DataMaster\SmfRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class SmfController extends Controller
{
    use ApiResponse, Authorizable;

    private $smfRepository;

    public function __construct(SmfRepository $smfRepository)
    {
        $this->smfRepository = $smfRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->smfRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->smfRepository->show($id), 200);
    }

    public function store(SmfRequest $request)
    {
        $results = $this->smfRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(SmfRequest $request, $id)
    {
        $results = $this->smfRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->smfRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->smfRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
