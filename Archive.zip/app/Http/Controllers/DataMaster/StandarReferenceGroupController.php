<?php

namespace App\Http\Controllers\DataMaster;

use App\Interfaces\DataMaster\StandarReferenceGroupInterface as StandarReferenceGroupInterface;
use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\StandarReferenceGroupRequest;
use Illuminate\Http\Request;
use App\Traits\Authorizable;
use App\Traits\ApiResponse;

class StandarReferenceGroupController extends Controller
{
    use ApiResponse;
    use Authorizable;

    private $standarReferenceGroupRepository;

    public function __construct(StandarReferenceGroupInterface $standarReferenceGroupRepository)
    {
        $this->standarReferenceGroupRepository = $standarReferenceGroupRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->standarReferenceGroupRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->standarReferenceGroupRepository->show($id), 200);
    }

    public function store(StandarReferenceGroupRequest $request)
    {
        $results = $this->standarReferenceGroupRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(StandarReferenceGroupRequest $request, $id)
    {
        $results = $this->standarReferenceGroupRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function delete($id)
    {
        $results = $this->standarReferenceGroupRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->standarReferenceGroupRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
