<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\ItemRequest;
use App\Repositories\DataMaster\ItemRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class ItemController extends Controller
{
    use ApiResponse, Authorizable;

    private $itemRepository;

    public function __construct(ItemRepository $itemRepository)
    {
        $this->itemRepository = $itemRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->itemRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        $results = $this->itemRepository->findById($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }
        return $this->showOne($results['data'], 200);
    }

    public function store(ItemRequest $request)
    {
        $results = $this->itemRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(ItemRequest $request, $id)
    {
        $this->itemRepository->findById($id);

        $results = $this->itemRepository->update($request, $id);

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->itemRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->itemRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
