<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\HealthServiceProviderRequest;
use App\Repositories\DataMaster\HealthServiceProviderRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class HealthServiceProviderController extends Controller
{
    use ApiResponse, Authorizable;

    private $healthServiceProviderRepository;

    public function __construct(HealthServiceProviderRepository $healthServiceProviderRepository)
    {
        $this->healthServiceProviderRepository = $healthServiceProviderRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->healthServiceProviderRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->healthServiceProviderRepository->show($id), 200);
    }

    public function store(HealthServiceProviderRequest $request)
    {
        $results = $this->healthServiceProviderRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(HealthServiceProviderRequest $request, $id)
    {
        $results = $this->healthServiceProviderRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->healthServiceProviderRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->healthServiceProviderRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
