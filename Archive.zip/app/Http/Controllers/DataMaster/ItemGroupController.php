<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\ItemGroupRequest;
use App\Repositories\DataMaster\ItemGroupRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class ItemGroupController extends Controller
{
    use ApiResponse, Authorizable;

    private $itemGroupRepository;

    public function __construct(ItemGroupRepository $itemGroupRepository)
    {
        $this->itemGroupRepository = $itemGroupRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->itemGroupRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->itemGroupRepository->findById($id), 200);
    }

    public function store(ItemGroupRequest $request)
    {
        $results = $this->itemGroupRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(ItemGroupRequest $request, $id)
    {
        $results = $this->itemGroupRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->itemGroupRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->itemGroupRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
