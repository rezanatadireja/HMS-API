<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\BedRequest;
use App\Repositories\DataMaster\BedRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class BedController extends Controller
{
    use ApiResponse, Authorizable;

    private $bedRepository;

    public function __construct(BedRepository $bedRepository)
    {
        $this->bedRepository = $bedRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->bedRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        $results = $this->bedRepository->show($id);
        return $results['status'] === 'error' ? $this->errorResponse($results['message'], 404) 
        : $this->showOne($this->bedRepository->show($id), 200);
    }

    public function store(BedRequest $request)
    {
        $results = $this->bedRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(BedRequest $request, $id)
    {
        $results = $this->bedRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->bedRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->bedRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}