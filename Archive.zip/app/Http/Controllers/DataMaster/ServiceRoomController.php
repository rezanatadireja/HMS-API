<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\ServiceRoomRequest;
use App\Repositories\DataMaster\ServiceRoomRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class ServiceRoomController extends Controller
{
    use ApiResponse, Authorizable;

    private $serviceRoomRepository;

    public function __construct(ServiceRoomRepository $serviceRoomRepository)
    {
        $this->serviceRoomRepository = $serviceRoomRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->serviceRoomRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        $results = $this->serviceRoomRepository->show($id);
        return $results['status'] === 'error' ? $this->errorResponse($results['message'], 404) 
        : $this->showOne($this->serviceRoomRepository->show($id), 200);
    }

    public function store(ServiceRoomRequest $request)
    {
        $results = $this->serviceRoomRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(ServiceRoomRequest $request, $id)
    {
        $results = $this->serviceRoomRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->serviceRoomRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->serviceRoomRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}