<?php

namespace App\Http\Controllers\DataMaster;

use App\Http\Controllers\Controller;
use App\Http\Requests\DataMaster\GuarantorRequest;
use App\Repositories\DataMaster\GuarantorRepository;
use App\Traits\ApiResponse;
use App\Traits\Authorizable;
use Illuminate\Http\Request;

class GuarantorConntroller extends Controller
{
    use ApiResponse, Authorizable;

    private $guarantorRepository;

    public function __construct(GuarantorRepository $guarantorRepository)
    {
        $this->guarantorRepository = $guarantorRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->guarantorRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        $results = $this->guarantorRepository->findById($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }
        return $this->showOne($results['data'], 200);
    }

    public function store(GuarantorRequest $request)
    {
        $results = $this->guarantorRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(GuarantorRequest $request, $id)
    {
        $this->guarantorRepository->findById($id);

        $results = $this->guarantorRepository->update($request, $id);

        return $this->successResponse($results['message'], 200);
    }

    public function destroy($id)
    {
        $results = $this->guarantorRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function status_update(Request $request, $id)
    {
        $results = $this->guarantorRepository->status_update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
