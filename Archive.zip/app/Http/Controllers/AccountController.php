<?php

namespace App\Http\Controllers;

use App\Interfaces\DataMaster\AccountInterface as AccountInterface;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Traits\Authorizable;
use App\Traits\ApiResponse;
use App\Models\Periode;

class AccountController extends Controller
{
    use ApiResponse;
    use Authorizable;

    private $accountRepository;

    public function __construct(AccountInterface $accountRepository)
    {
        $this->accountRepository = $accountRepository;
    }

    public function data(Request $request){
        return $this->showAll($this->accountRepository->data($request),200);
    }
    public function show($id)
	{
        return $this->showOne($this->accountRepository->show($id),200);
	}
    public function create(Request $request)
	{

		$results = $this->accountRepository->create($request);

		if (!$results['status']) {
			return $this->errorResponse($results['message'], 404);
		}

        return $this->successResponse($results['message'], 200);
	}
    public function update(Request $request, $id)
    {
        $results = $this->accountRepository->update($request, $id);

		if (!$results['status']) {
			return $this->errorResponse($results['message'], 404);
		}

        return $this->successResponse($results['message'], 200);

	}

	public function delete($id)
    {
        $results = $this->accountRepository->delete($id);

        if (!$results['status']) {
			return $this->errorResponse($results['message'], 404);
		}

        return $this->successResponse($results['message'], 200);

	}
    public function status_update(Request $request, $id)
    {
        $results = $this->accountRepository->status_update($request, $id);

		if (!$results['status']) {
			return $this->errorResponse($results['message'], 404);
		}

        return $this->successResponse($results['message'], 200);

	}


}
