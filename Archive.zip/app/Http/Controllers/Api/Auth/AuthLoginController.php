<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\Traits\ApiResponse;
use Auth,JWTAuth;
use App\Models\User;
use Carbon\Carbon;

class AuthLoginController extends Controller
{
    use ApiResponse;
    protected $login_max = 5;

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            // 'email' => 'required|email|exists:users,email',
            'username' => 'required',
            'password' => 'required',
        ]);

        if($validator->fails()){
            return $this->errorResponse($validator->errors(),419,419);
        }

        $validation_login = $this->validLogin($request);

        if (!$validation_login['valid_login']) {
            return $this->errorResponse($validation_login['messages'],401,401);
		}

        $credentials = $request->only('username', 'password');

        try {
            if (! $token = JWTAuth::attempt($credentials)) {
                return $this->errorResponse("Invalid Credential, please try again",400);
            }
        } catch (JWTException $e) {
            return $this->errorResponse('Could Not Create Token',500,500);

        }
        $user = JWTAuth::user();

        $user_data = User::where([
			'username' => $request->username
		]);
		$user_data->update([
			'count_login' => 0,
			'log_date' => Carbon::now()->toDateString(),
			'is_banned' => 0
		]);
        $res = [
            'lastLoginFrom' => request()->ip(),
            'token' => $token,
            'user_data'=>[
                'id'=>$user->id,
                'name'=>$user->name,
                'email'=>$user->email
            ],
            'roles' => $user->getRoleNames()
        ];

        return $this->successResponse($res,200,200);


    }

    public function validLogin($request)
	{
		$messages = [];
		$valid_login = false;

		$user_data = User::where([
			'username' => $request->username
		]);

		if ($user_data->exists()) {
			$user = $user_data->first();
			$login_count = $user->log_date == Carbon::now()->toDateString() ? $user->count_login : 0;
			$login_max = $this->login_max;

			if ($login_max <= $login_max && $user->status == 1) {
				$messages[] = 'Username atau password salah.';

				if (app('hash')->check($request->password, $user->password) && $login_count < $login_max) {
					$valid_login = true;
					return ['messages' => $messages , 'valid_login' => $valid_login];
				}

				$valid_login = false;
				$login_count++;

				if ($login_count < $login_max) {
					$is_banned = false;
					$messages[] = 'Kesempatan anda untuk login ' . ($login_max - $login_count) . ' kali lagi.';
				} else {
					$is_banned = true;
					$messages[] = 'Kesempatan login anda sudah habis , silahkan hubungi Administrator.';
				}

				$user->update([
					'count_login' => $login_count,
					'log_date' => Carbon::now()->toDateString(),
					'is_banned' => $is_banned
				]);

			} else {
				$messages[] = 'Anda sudah tidak bisa login , silahkan hubungi Administrator.';
			}

		} else {
			$messages[] = 'Akun anda belum terdaftar.';
		}

		return ['messages' => $messages , 'valid_login' => $valid_login];
	}
    public function getAuthenticatedUser()
    {
        try {

            if (! $user = JWTAuth::parseToken()->authenticate()) {
                return response()->json(['user_not_found'], 404);
            }

        } catch (Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {

            return response()->json(['token_expired'], $e->getStatusCode());

        } catch (Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {

            return response()->json(['token_invalid'], $e->getStatusCode());

        } catch (Tymon\JWTAuth\Exceptions\JWTException $e) {

            return response()->json(['token_absent'], $e->getStatusCode());

        }

        return response()->json(compact('user'));
    }

    public function logout(Request $request)
    {
        try {
            auth('api')->logout(true);

            return $this->successResponse("Success Logout",200,200);
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(),201);
        }
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
        ]);

        if($validator->fails()){
            return $this->errorResponse($validator->errors(),419);
        }

        $user = User::create([
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'password' => Hash::make($request->get('password')),
        ]);

        if(!$user){
            return $this->errorResponse('Registrasi Gagal',500);
        }

        $token = JWTAuth::fromUser($user);
        $res = [
            'token' => $token,
            'user_info' => [
                'name'=>$user->name,
                'email'=>$user->email
			]
        ];
        return $this->successResponse($res,'User Registration Success',200);

    }
}
