<?php

namespace App\Http\Controllers;

use App\Interfaces\DataMaster\MenuManagementInterface as MenuManagementInterface;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Traits\Authorizable;
use App\Traits\ApiResponse;

class MenuManagementController extends Controller
{
    use ApiResponse, Authorizable;

    private $menuManagementRepository;

    public function __construct(MenuManagementInterface $menuManagementRepository)
    {
        $this->menuManagementRepository = $menuManagementRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->menuManagementRepository->data($request), 200, $paginate);
    }
    public function tree()
    {
        return $this->successResponse($this->menuManagementRepository->tree(), 200);
    }
    public function show($id)
    {
        return $this->showOne($this->menuManagementRepository->show($id), 200);
    }
    public function create(Request $request)
    {

        $results = $this->menuManagementRepository->store($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
    public function update(Request $request, $id)
    {
        $results = $this->menuManagementRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function delete($id)
    {
        $results = $this->menuManagementRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
