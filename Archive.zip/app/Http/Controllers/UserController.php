<?php

namespace App\Http\Controllers;

use App\Interfaces\UserManagement\UserInterface as UserInterface;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Traits\Authorizable;
use App\Traits\ApiResponse;
use App\Models\Periode;

class UserController extends Controller
{
    use ApiResponse;
    use Authorizable;

    private $userRepository;

    public function __construct(UserInterface $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     *    @OA\Get(
     *       path="/users",
     *       tags={"Users"},
     *       operationId="UsersManagement",
     *       summary="Users",
     *       description="Mengambil Data Users",
     *       @OA\Response(
     *           response="200",
     *           description="Ok",
     *           @OA\JsonContent
     *           (example={
     *               "success": true,
     *               "message": "Berhasil mengambil Users",
     *               "data": {
     *                   {
     *                   "id": "1",
     *                   "username": "admin@test.com",
     *                  }
     *              }
     *          }),
     *      ),
     *  )
     */

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->userRepository->data($request), 200, $paginate);
    }
    public function show($id)
    {
        return $this->showOne($this->userRepository->show($id), 200);
    }
    public function create(Request $request)
    {

        $results = $this->userRepository->create($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
    public function update(Request $request, $id)
    {
        $results = $this->userRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function delete($id)
    {
        $results = $this->userRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function change_password(Request $request, $id)
    {
        $results = $this->userRepository->change_password($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
