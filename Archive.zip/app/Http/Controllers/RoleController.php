<?php

namespace App\Http\Controllers;

use App\Interfaces\UserManagement\RoleInterface as RoleInterface;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Traits\Authorizable;
use App\Traits\ApiResponse;
use App\Models\Periode;

class RoleController extends Controller
{
    use ApiResponse;
    use Authorizable;

    private $roleRepository;

    public function __construct(RoleInterface $roleRepository)
    {
        $this->roleRepository = $roleRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->roleRepository->data($request), 200, $paginate);
    }

    public function show($id)
    {
        return $this->showOne($this->roleRepository->show($id), 200);
    }

    public function create(Request $request)
    {

        $results = $this->roleRepository->create($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function update(Request $request, $id)
    {
        $results = $this->roleRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function delete($id)
    {
        $results = $this->roleRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
