<?php

namespace App\Http\Controllers;

use App\Interfaces\UserManagement\PermissionInterface as PermissionInterface;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Traits\Authorizable;
use App\Traits\ApiResponse;
use App\Models\Periode;

class PermissionController extends Controller
{
    use ApiResponse;
    use Authorizable;

    private $permissionRepository;

    /**
     * @OA\Info(
     *      version="1.0.0",
     *      title="HMS API",
     *      description="HMS API Documentation",
     *      @OA\Contact(
     *          email="rezafeisalfajri@gmail.com"
     *      ),
     *      @OA\License(
     *          name="Apache 2.0",
     *          url="http://www.apache.org/licenses/LICENSE-2.0.html"
     *      )
     * )
     *
     * @OA\Server(
     *      url=L5_SWAGGER_CONST_HOST,
     *      description="Demo API Server"
     * )
     */

    public function __construct(PermissionInterface $permissionRepository)
    {
        $this->permissionRepository = $permissionRepository;
    }

    public function data(Request $request)
    {
        if ($request->get('paginate') == "true") {
            $paginate = true;
        } else {
            $paginate = false;
        }
        return $this->showAll($this->permissionRepository->data($request), 200, $paginate);
    }
    public function show($id)
    {
        return $this->showOne($this->permissionRepository->show($id), 200);
    }
    public function create(Request $request)
    {

        $results = $this->permissionRepository->create($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
    public function update(Request $request, $id)
    {
        $results = $this->permissionRepository->update($request, $id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function delete($id)
    {
        $results = $this->permissionRepository->delete($id);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function show_permission_by_user($id)
    {
        $results = $this->permissionRepository->show_permission_by_user($id);

        return $this->successResponse($results, 200);
    }

    public function generate(Request $request)
    {
        $results = $this->permissionRepository->generate($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }

    public function reset(Request $request)
    {
        $results = $this->permissionRepository->reset($request);

        if (!$results['status']) {
            return $this->errorResponse($results['message'], 404);
        }

        return $this->successResponse($results['message'], 200);
    }
}
