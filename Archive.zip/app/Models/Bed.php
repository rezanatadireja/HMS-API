<?php

namespace App\Models;

use App\Traits\UuidForKey;
use App\Transformers\DataMaster\BedTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Bed extends Model
{
    use UuidForKey, HasFactory;

    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $transformer = BedTransformer::class;

    protected $fillable = [
        'room_id',
        'ref_bed_status',
        'old_bed_id',
        'default_charge_class_id',
        'registration_no',
        'bed_status_updated_by',
        'is_temporary',
        'is_need_confirmation',
        'is_room_in',
        'booking_date_time',
        'is_visible_3rd_party',
        'notes',
        'owner_user_id',
        'status',
        'created_by',
        'updated_by',
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
