<?php

namespace App\Models;

use App\Models\BaseModel;
use App\Transformers\DataMaster\ItemGroupTransformer;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Auth;

class ItemGroup extends BaseModel
{
    public $transformer = ItemGroupTransformer::class;
    protected $fillable = [
        'ref_item_type',
        'name',
        'cito_value',
        'is_cito_in_patient',
        'initial',
        'restriction_user_type',
        'status',
        'created_by',
        'updated_by',
    ];

    public function items(): HasMany
    {
        return $this->hasMany(Item::class);
    }

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
            $model->updated_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
