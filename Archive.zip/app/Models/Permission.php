<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Models\Permission as SpatiePermission;
use App\Transformers\PermissionTransformer;
use App\Traits\UuidForKey;

class Permission extends SpatiePermission
{
    use UuidForKey;
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    // public $guard_name = 'api';

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'string'
    ];

    public $transformer = PermissionTransformer::class;
    public static function defaultPermissions()
    {
        return [
            'view_users',
            'add_users',
            'edit_users',
            'delete_users',

            'view_roles',
            'add_roles',
            'edit_roles',
            'delete_roles',

            'view_permissions',
            'add_permissions',
            'edit_permissions',
            'delete_permissions',
        ];
    }
}
