<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Traits\UuidForKey;

class BaseModel extends Model
{
    use UuidForKey;

    /*Ini Paling Penting Untuk Generate UUID*/
    public $keyType = 'string';
    public $incrementing = false;

    public function scopeData($query, $key = NULL, $orderBy = 'created_at', $direction = 'desc', $offset = 0, $limit = 0)
    {
        if (is_array($key)) {
            $query->where($key);
        }

        if (!empty($offset) || !empty($limit)) {
            $query->take($limit)->skip($offset);
        }

        if (!empty($orderBy)) {
            $query->orderBy($orderBy, $direction);
        }
        return $query;
    }

    public function scopeOptions($query, $key = NULL, $default = NULL)
    {

        if (!empty($key) && !is_array($key)) {
            $query->find($key);
        }

        $list_default = ['' => '-'];

        if ($default) {
            $list_default = $default;
        }

        $list = $list_default;

        foreach ($query->data($key, 'name')->get() as $dt) {
            $list[$dt->id] = $dt->name;
        }

        return $list;
    }

    public function scopeIsActive($query)
    {
        return $query->where('status', 1);
    }

    public function scopeOption2($query, $request, $searchIn, $selects)
    {
        $query->select($selects);

        if ($request->has('q')) {
            $query->where(function ($query) use ($request, $searchIn) {
                foreach ($searchIn as $idx => $field) {
                    if ($idx == 0) {
                        $query->where($field, 'like', "%{$request->get('q')}%");
                    } else {
                        $query->orWhere($field, 'like', "%{$request->get('q')}%");
                    }
                }
            });
        }
        return $query;
    }

    public function scopeOptionsDef($query, $key = NULL, $default = NULL)
    {

        if (!empty($key) && !is_array($key)) {
            $query->find($key);
        }

        $default = [];

        $list = $default;

        foreach ($query->data($key, 'name')->get() as $dt) {
            $list[$dt->id] = $dt->name;
        }

        return $list;
    }

    public function scopeDataByDepartment($query)
    {
        return $query->where('department_id', auth()->user()->active_department_id);
    }

    public function scopeChained($query, $key = [])
    {
        return $query->select('id','name')->whereRaw($key);
    }

    public function scopeWhereDepartment($query, $key = [],$id_selection)
    {
        return $query->where($key)->pluck($id_selection)->toArray();
    }

    public function scopeWhereSync($query,$key = [])
    {
        return $query->where($key);
    }
}
