<?php

namespace App\Models;

use App\Traits\UuidForKey;
use App\Transformers\DataMaster\AppParameterTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class AppParameter extends Model
{
    use UuidForKey, HasFactory;

    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $transformer = AppParameterTransformer::class;

    protected $fillable = [
        'name',
        'value',
        'type',
        'is_used_by_system',
        'message',
        'created_by',
        'updated_by',
    ];

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
            $model->updated_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
