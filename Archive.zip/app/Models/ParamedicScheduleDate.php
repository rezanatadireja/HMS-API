<?php

namespace App\Models;

use App\Traits\UuidForKey;
use App\Transformers\DataMaster\ParamedicScheduleDateTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class ParamedicScheduleDate extends Model
{
    use UuidForKey, HasFactory;

    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $transformer = ParamedicScheduleDateTransformer::class;

    protected $fillable = [
        'service_unit_id',
        'paramedic_id',
        'operational_time_id',
        'period_year',
        'schedule_date',
        'is_closed_time_1',
        'losed_time_1',
        'closed_time_1_by_user_id',
        'is_closed_time_2',
        'losed_time_2',
        'closed_time_2_by_user_id',
        'is_closed_time_3',
        'losed_time_3',
        'closed_time_3_by_user_id',
        'is_closed_time_4',
        'losed_time_4',
        'closed_time_4_by_user_id',
        'is_closed_time_5',
        'losed_time_5',
        'closed_time_5_by_user_id',
        'is_ipr',
        'is_opr',
        'is_emr',
        'period_month',
        'add_quota',
        'add_quota_online',
        'add_quota_bpjs',
        'add_quota_bpjs_online',
        'owner_user_id',
        'created_by',
        'updated_by',
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
