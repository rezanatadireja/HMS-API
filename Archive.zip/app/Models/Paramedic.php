<?php

namespace App\Models;

use App\Traits\UuidForKey;
use App\Transformers\DataMaster\ParamedicTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Paramedic extends Model
{
    use UuidForKey, HasFactory;

    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $transformer = ParamedicTransformer::class;

    protected $fillable = [
        'employee_id',
        'ref_paramedic_type',
        'ref_paramedic_status',
        'ref_speciality',
        'name',
        'initial',
        'date_of_birth',
        'notes',
        'status',
        'created_by',
        'updated_by',
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
