<?php

namespace App\Models;

use App\Traits\UuidForKey;
use App\Transformers\DataMaster\LocationTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Location extends Model
{
    use UuidForKey, HasFactory;

    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $transformer = LocationTransformer::class;

    protected $fillable = [
        'parent_id',
        'item_group_id',
        'permit_id',
        'ref_type_of_inventory',
        'ref_stock_group',
        'chart_of_account_id_income',
        'subledger_id_income',
        'chart_of_account_id_inventory',
        'chart_of_account_id_cogs',
        'subledger_id_cogs',
        'chart_of_account_id_sales_return',
        'subledger_id_sales_return',
        'chart_of_account_id_purchase_return',
        'subledger_id_purchase_return',
        'chart_of_account_id_acrual',
        'subledger_id_acrual',
        'chart_of_account_id_discount',
        'subledger_id_discount',
        'chart_of_account_id_cost',
        'subledger_id_cost',
        'name',
        'short_name',
        'is_header',
        'is_hold_for_transaction',
        'is_allowed_to_stock_goods',
        'is_consignment',
        'is_validate_max_value_on_dist_req_for_ipm',
        'is_validate_max_value_on_dist_req_for_ipnm',
        'is_validate_max_value_on_dist_req_for_ik',
        'is_validate_max_value_on_purc_req_for_ipm',
        'is_validate_max_value_on_purc_req_for_ipnm',
        'is_validate_max_value_on_purc_req_for_ik',
        'last_hold_for_transaction_date_time',
        'last_hold_for_transaction_by_user_id',
        'is_auto_update_stock_min_max',
        'status',
        'owner_user_id',
        'created_by',
        'updated_by'
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }
    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
