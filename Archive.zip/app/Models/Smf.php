<?php

namespace App\Models;

use App\Traits\UuidForKey;
use App\Transformers\DataMaster\SmfTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Smf extends Model
{
    use UuidForKey;

    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $transformer = SmfTransformer::class;

    protected $fillable = [
        'ref_paramedic_fee_cash_type',
        'ref_assesment_type',
        'name',
        'status',
        'created_by',
        'updated_by',
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }
    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
            $model->updated_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
