<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\BaseModel;
use App\Transformers\DataMaster\ItemTransformer;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Auth;

class Item extends BaseModel
{
    public $transformer = ItemTransformer::class;
    protected $fillable = [
        'item_group_id',
        'asset_group_id',
        'ref_item_type',
        'ref_billing_group',
        'ref_item_category',
        'ref_item_sub_group',
        'name',
        'is_item_production',
        'barcode',
        'image',
        'validity_period_from',
        'validity_period_to',
        'is_asset',
        'is_delegation_to_nurse',
        'is_new_upload',
        'status',
        'notes',
        'created_by',
        'updated_by',
    ];

    public function itemGroup(): BelongsTo
    {
        return $this->belongsTo(ItemGroup::class, 'item_group_id');
    }

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
            $model->updated_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
