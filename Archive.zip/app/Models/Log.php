<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\BaseModel;

class Log extends BaseModel
{
    protected $fillable = [
        'id',
        'user_id',
        'model',
        'type',
        'reference_id',
        'activity',
        'visitor'
    ];

    public function user()
    {
        return $this->belongsTo('App\Models\User');
    }
}
