<?php

namespace App\Models;

use App\Traits\UuidForKey;
use App\Transformers\DataMaster\ServiceRoomTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class ServiceRoom extends Model
{
    use UuidForKey, HasFactory;

    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $transformer = ServiceRoomTransformer::class;

    protected $fillable = [
        'department_id',
        'floor_id',
        'ref_gender_type',
        'name',
        'is_operation_room',
        'is_bpjs',
        'is_isolation_room',
        'is_negative_pressure_room',
        'is_pandemic_room',
        'is_ventilator',
        'notes',
        'status',
        'owner_user_id',
        'created_by',
        'updated_by'
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
