<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\BaseModel;
use App\Transformers\DataMaster\GuarantorTransformer;
use Illuminate\Support\Facades\Auth;

class Guarantor extends BaseModel
{
    public $transformer = GuarantorTransformer::class;
    protected $fillable = [
        'ref_guarantor_type',
        'ref_business_method',
        'ref_guarantor_rule_type',
        'ref_payment_type',
        'code',
        'name',
        'short_name',
        'contract_number',
        'contract_start',
        'contract_end',
        'contract_summary',
        'street_name',
        'teritory_id',
        'country_id',
        'zip_code',
        'phone_no',
        'fax_no',
        'email',
        'mobile_phone_no',
        'is_cover_inpatient',
        'is_cover_outpatient',
        'status',
        'created_by',
        'updated_by',
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
            $model->updated_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
