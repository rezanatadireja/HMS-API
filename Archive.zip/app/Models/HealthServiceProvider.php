<?php

namespace App\Models;

use App\Models\BaseModel;
use App\Transformers\DataMaster\HealthServiceProviderTransformer;
use Illuminate\Support\Facades\Auth;

class HealthServiceProvider extends BaseModel
{
    public $transformer = HealthServiceProviderTransformer::class;
    protected $fillable = [
        'teritory_id',
        'name',
        'address_line_1',
        'address_line_2',
        'zip_code',
        'phone_no',
        'fax_no',
        'code',
        'email_address',
        'website',
        'npwp',
        'hospital_type',
        'additional_info',
        'logo',
        'created_by',
        'updated_by',
        'owner_user_id',
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }
    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
            $model->updated_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
