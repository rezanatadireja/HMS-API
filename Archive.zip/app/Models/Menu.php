<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Transformers\DataMaster\MenuManagementTransformer;
use App\Traits\UuidForKey;
use Illuminate\Support\Facades\Auth;

class Menu extends BaseModel
{
    public $transformer = MenuManagementTransformer::class;

    protected $fillable = [
        'parent_id',
        'name',
        'icon',
        'url',
        'roles',
        'is_service_menu',
    ];

    public function childs()
    {
        return $this->hasMany('App\Models\Menu', 'parent_id', 'id');
    }

    public static function toTree($listMenu, $parentId = null)
    {
        $tree = [];

        foreach ($listMenu as $menu) {
            if ($menu->parent_id == $parentId) {
                $menu->childs = self::toTree($listMenu, $menu->id);
                $tree[] = $menu;
            }
        }

        return $tree;
    }
}
