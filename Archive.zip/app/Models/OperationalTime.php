<?php

namespace App\Models;

use App\Traits\UuidForKey;
use App\Transformers\DataMaster\OperationalTimeTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class OperationalTime extends Model
{
    use UuidForKey, HasFactory;

    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $transformer = OperationalTimeTransformer::class;

    protected $fillable = [
        'name',
        'start_time_1',
        'end_time_1',
        'start_time_2',
        'end_time_2',
        'start_time_3',
        'end_time_3',
        'start_time_4',
        'end_time_4',
        'start_time_5',
        'end_time_5',
        'time_back_color',
        'owner_user_id',
        'created_by',
        'updated_by',
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
