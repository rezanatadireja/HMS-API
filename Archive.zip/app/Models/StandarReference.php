<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Transformers\DataMaster\StandarReferenceTransformer;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\BaseModel;
use Auth;


class StandarReference extends BaseModel
{
    public $transformer = StandarReferenceTransformer::class;

    protected $fillable = [
        'standar_reference_group_id',
        'name',
        'code',
        'status',
        'owner_user_id',
        'created_by',
        'updated_by'
    ];

    public function standarReferenceGroup(): BelongsTo
    {
        return $this->belongsTo(StandarReferenceGroup::class, 'standar_reference_group_id');
    }
    public function standarReferenceItem(): HasMany
    {
        return $this->hasMany(StandarReferenceItem::class);
    }
    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }
    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }
    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
            $model->updated_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
