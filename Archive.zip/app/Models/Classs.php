<?php

namespace App\Models;

use App\Traits\UuidForKey;
use App\Transformers\DataMaster\ClassTransformer;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Classs extends Model
{
    use UuidForKey, HasFactory;

    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $transformer = ClassTransformer::class;

    protected $fillable = [
        'bpjs_class_id',
        'ref_class_id',
        'name',
        'short_name',
        'margin_percentage',
        'margin_2_percentage',
        'deposit_ammount',
        'is_in_patient_class',
        'is_tariff_class',
        'class_sequence',
        'status',
    ];

    public function scopeActivate($query)
    {
        return $query->update(['status' => 1]);
    }

    public function scopeDeactivate($query)
    {
        return $query->update(['status' => 0]);
    }

    protected static function booted()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->created_by = Auth::user()->id;
            $model->updated_by = Auth::user()->id;
        });

        static::updating(function ($model) {
            $model->updated_by = Auth::user()->id;
        });
    }
}
