<?php

namespace App\Listeners;

use App\Events\LogWasEror;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Models\Log;
use Auth;

class LogEror
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  LogWasEror  $event
     * @return void
     */
    public function handle(LogWasEror $event)
    {

        $createlog = Log::create([
            'user_id' => Auth::check() ? Auth::user()->id : NULL,
            'model' =>$event->actionLog['model'],
            'type' => 'eror',
            'activity' => $event->actionLog['message'],
            'visitor' => app('request')->ip()
        ]);

        return $createlog->id;
    }
}
