<?php

namespace App\Listeners;

use App\Events\LogWasCreate;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Models\Log;
use Auth;

class LogCreate
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  LogWasCreate  $event
     * @return void
     */
    public function handle(LogWasCreate $event)
    {
        $name = class_basename($event->actionLog);
        $model = str_replace('Model', '', $name);

        Log::create([
            'user_id' => Auth::check() ? Auth::user()->id : NULL,
            'model' => $model,
            'type' => 'created',
            'reference_id' => $event->actionLog->id,
            'activity' => "Melakukan penambahan pada data {$model} ",
            'visitor' => app('request')->ip()
        ]);
    }
}
