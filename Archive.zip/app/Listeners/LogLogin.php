<?php

namespace App\Listeners;

use App\Events\LogWasLogin;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Models\Log;
use Auth;

class LogLogin
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  LogWasLogin  $event
     * @return void
     */
    public function handle(LogWasLogin $event)
    {

        Log::create([
            'user_id' => Auth::check() ? Auth::user()->id : NULL,
            'model' => 'Login',
            'type' => 'Login',
            'activity' => "Melakukan Login",
            'visitor' => app('request')->ip()
        ]);
    }
}
