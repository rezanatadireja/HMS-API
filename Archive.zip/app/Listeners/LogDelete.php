<?php

namespace App\Listeners;

use App\Events\LogWasDelete;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Models\Log;
use Auth;

class LogDelete
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  LogWasDelete  $event
     * @return void
     */
    public function handle(LogWasDelete $event)
    {
        $name = class_basename($event->actionLog);
        $model = str_replace('Model', '', $name);

        Log::create([
            'user_id' => Auth::user()->id,
            'model' => $model,
            'type' => 'deleted',
            'reference_id' => $event->actionLog->id,
            'activity' => "Melakukan penghapusan pada data {$model} ",
            'visitor' => app('request')->ip()
        ]);
    }
}
