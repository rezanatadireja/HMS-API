
<?php

use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Carbon\CarbonInterval;
use App\Models\User;
use phpseclib3\Crypt\AES;
use phpseclib3\Crypt\Random;


if (!function_exists('getRangeDateInWeek')) {

    function getRangeDateInWeek()
    {
       $now = Carbon::now();
       $startMonth = $now->startOfWeek()->format('m');
       $endMonth = $now->endOfWeek()->format('m');

       if($startMonth < $endMonth){
            $starDate = Carbon::parse(Carbon::now()->format('Y').'-'.Carbon::now()->format('m').'-01')->format('Y-m-d');
       }else{
            $starDate= $now->startOfWeek()->format('Y-m-d');
       }


       if($endMonth > Carbon::now()->format('m')){
            $endDate = $now->endOfMonth();
       }else{
            $endDate= $now->endOfWeek()->format('Y-m-d');
       }

       $data = [
        'start_date'=>$starDate,
        'end_date'=>$endDate
       ];
       return $data;
    }

    function periodeDate($startDate ='',$endDate ='',$inclusive = true)
    {
        $period = CarbonPeriod::between($startDate, $endDate);

        $dates = [];

        foreach ($period as $date) {
            $dates[] = $date->format('Y-m-d');
        }

        return $dates;
    }

}
if (!function_exists('getUsername')) {

    function getUsername($id)
    {
        $data = User::where('id',$id)->first();
        return $data ? $data->username:'Unidentified User';
    }

}



