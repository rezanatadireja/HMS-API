<?php

namespace App\Helpers;

use App\Events\LogWasCreate;
use App\Events\LogWasUpdate;
use App\Events\LogWasDelete;
use App\Events\LogWasLogin;
use App\Events\LogWasEror;

class LogHelper{

    public static function created_log($actionLog = [])
    {
        $createLog = event(new LogWasCreate($actionLog));
    }

    public static function updated_log($actionLog = [])
    {
        $createLog = event(new LogWasUpdate($actionLog));
    }

    public static function created_history($actionLog = [])
    {
        $createLog = event(new LogWasSurgery($actionLog));
    }

    public static function deleted_log($actionLog = [])
    {
        $createLog = event(new LogWasDelete($actionLog));
    }

    public static function login_log()
    {
        $createLog = event(new LogWasLogin());
    }
    public static function error_log($actionLog = [])
    {
        $createLog = event(new LogWasEror($actionLog));
        return $createLog;
    }

}

