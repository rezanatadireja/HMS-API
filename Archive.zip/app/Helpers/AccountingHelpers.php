<?php


use App\Models\Account;


if (!function_exists('getTopParentAccount')) {

    function getTopParentAccount($id)
    {
        $cat = Account::find($id);
        $parent = optional($cat)->parentAccount;
        $catName = empty($cat) ? '-':$cat->name ;
        return $parent ? getTopParentAccount($parent->id) :  $catName;
    }
}
