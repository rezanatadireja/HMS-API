<?php

namespace App\Transformers\DataMaster;

use App\Transformers\DataMaster\StandarReferenceItemTransformer;
use League\Fractal\TransformerAbstract;
use Carbon\Carbon;

class ItemTransformer extends TransformerAbstract
{
    /**
     * List of resources to automatically include
     *
     * @var array
     */
    protected array $defaultIncludes = [
        //
    ];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected array $availableIncludes = [
        //
    ];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform($data)
    {
        return [
            'id' => $data->id,
            'item_group_id' => $data->item_group_id,
            'asset_group_id' => $data->asset_group_id,
            'ref_item_type' => $data->ref_item_type,
            'ref_billing_group' => $data->ref_billing_group,
            'ref_item_category' => $data->ref_item_category,
            'ref_item_sub_group' => $data->ref_item_sub_group,
            'name' => $data->name,
            'is_item_production' => $data->is_item_production,
            'barcode' => $data->barcode,
            'image' => $data->image,
            'validity_period_from' => $data->validity_period_from,
            'validity_period_to' => $data->validity_period_to,
            'is_asset' => $data->is_asset,
            'is_delegation_to_nurse' => $data->is_delegation_to_nurse,
            'notes' => $data->notes,
            'created_by' => $data->created_by ? getUsername($data->created_by) : 'Unidentified User',
            'updated_by' => $data->updated_by ? getUsername($data->updated_by) : 'Unidentified User',
            'created_at' => Carbon::parse($data->created_at)->format('d/m/Y H:i:s'),
            'udpated_at' => Carbon::parse($data->updated_at)->format('d/m/Y H:i:s')
        ];
    }
}
