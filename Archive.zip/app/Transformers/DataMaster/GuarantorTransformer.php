<?php

namespace App\Transformers\DataMaster;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

class GuarantorTransformer extends TransformerAbstract
{
    /**
     * List of resources to automatically include
     *
     * @var array
     */
    protected array $defaultIncludes = [
        //
    ];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected array $availableIncludes = [
        //
    ];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform($data)
    {
        return [
            'id' => $data->id,
            'ref_guarantor_type' => $data->ref_guarantor_type,
            'ref_business_method' => $data->ref_business_method,
            'ref_guarantor_rule_type' => $data->ref_guarantor_rule_type,
            'ref_payment_type' => $data->ref_payment_type,
            'code' => $data->code,
            'name' => $data->name,
            'short_name' => $data->short_name,
            'contract_number' => $data->contract_number,
            'contract_start' => $data->contract_start,
            'contract_end' => $data->contract_end,
            'contract_summary' => $data->contract_summary,
            'street_name' => $data->street_name,
            'teritory_id' => $data->teritory_id,
            'country_id' => $data->country_id,
            'zip_code' => $data->zip_code,
            'phone_no' => $data->phone_no,
            'fax_no' => $data->fax_no,
            'email' => $data->email,
            'mobile_phone_no' => $data->mobile_phone_no,
            'is_cover_inpatient' => $data->is_cover_inpatient,
            'is_cover_outpatient' => $data->is_cover_outpatient,
            'status' => $data->status,
            'created_by' => $data->created_by ? getUsername($data->created_by) : 'Unidentified User',
            'updated_by' => $data->updated_by ? getUsername($data->updated_by) : 'Unidentified User',
            'created_at' => Carbon::parse($data->created_at)->format('d/m/Y H:i:s'),
            'udpated_at' => Carbon::parse($data->updated_at)->format('d/m/Y H:i:s')
        ];
    }
}
