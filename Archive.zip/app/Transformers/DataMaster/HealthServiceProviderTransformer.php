<?php

namespace App\Transformers\DataMaster;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

class HealthServiceProviderTransformer extends TransformerAbstract
{
    /**
     * List of resources to automatically include
     *
     * @var array
     */
    protected array $defaultIncludes = [
        //
    ];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected array $availableIncludes = [
        //
    ];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform($data)
    {
        return [
            'id' => $data->id,
            'teritory_id' => $data->teritory_id,
            'name' => $data->name,
            'address_line_1' => $data->address_line_1,
            'address_line_2' => $data->address_line_2,
            'zip_code' => $data->zip_code,
            'phone_no' => $data->phone_no,
            'fax_no' => $data->fax_no,
            'code' => $data->code,
            'email_address' => $data->email_address,
            'website' => $data->website,
            'npwp' => $data->npwp,
            'hospital_type' => $data->hospital_type,
            'additional_info' => $data->additional_info,
            'logo' => $data->logo,
            'created_by' => $data->created_by ? getUsername($data->created_by) : 'Unidentified User',
            'updated_by' => $data->updated_by ? getUsername($data->updated_by) : 'Unidentified User',
            'created_at' => Carbon::parse($data->created_at)->format('d/m/Y H:i:s'),
            'udpated_at' => Carbon::parse($data->updated_at)->format('d/m/Y H:i:s')
        ];
    }
}
