<?php

namespace App\Transformers\DataMaster;

use Carbon\Carbon;
use League\Fractal\TransformerAbstract;

class AppParameterTransformer extends TransformerAbstract
{
    /**
     * List of resources to automatically include
     *
     * @var array
     */
    protected array $defaultIncludes = [
        //
    ];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected array $availableIncludes = [
        //
    ];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform($data)
    {
        return [
            'id' => $data->id,
            'name' => $data->name,
            'value' => $data->value,
            'type' => $data->type,
            'is_used_by_system' => $data->is_used_by_system,
            'message' => $data->message,
            'created_by' => $data->created_by ? getUsername($data->created_by) : 'Unidentified User',
            'updated_by' => $data->updated_by ? getUsername($data->updated_by) : 'Unidentified User',
            'created_at' => Carbon::parse($data->created_at)->format('d/m/Y H:i:s'),
            'udpated_at' => Carbon::parse($data->updated_at)->format('d/m/Y H:i:s')
        ];
    }
}
