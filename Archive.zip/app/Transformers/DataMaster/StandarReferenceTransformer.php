<?php

namespace App\Transformers\DataMaster;

use App\Transformers\DataMaster\StandarReferenceItemTransformer;
use League\Fractal\TransformerAbstract;
use Carbon\Carbon;

class StandarReferenceTransformer extends TransformerAbstract
{
    /**
     * List of resources to automatically include
     *
     * @var array
     */
    protected array $defaultIncludes = [
        //
    ];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected array $availableIncludes = [
        //
    ];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform($data)
    {
        $items  = fractal($data->standarReferenceItem, new StandarReferenceItemTransformer())->toArray();

        return [
            'id' => $data->id,
            'code' => $data->code,
            'name' => $data->name,
            'parent' => [
                "id" => $data->standarReferenceGroup->id,
                "name" => $data->standarReferenceGroup->name,
                'created_by' => $data->standarReferenceGroup->created_by ? getUsername($data->standarReferenceGroup->created_by) : 'Unidentified User',
                'updated_by' => $data->standarReferenceGroup->updated_by ? getUsername($data->standarReferenceGroup->updated_by) : 'Unidentified User',
                'created_at' => Carbon::parse($data->standarReferenceGroup->created_at)->format('d/m/Y H:i:s'),
                'udpated_at' => Carbon::parse($data->standarReferenceGroup->updated_at)->format('d/m/Y H:i:s')

            ],
            'items' => $items['data'],
            'created_by' => $data->created_by ? getUsername($data->created_by) : 'Unidentified User',
            'updated_by' => $data->updated_by ? getUsername($data->updated_by) : 'Unidentified User',
            'created_at' => Carbon::parse($data->created_at)->format('d/m/Y H:i:s'),
            'udpated_at' => Carbon::parse($data->updated_at)->format('d/m/Y H:i:s')
        ];
    }
}
