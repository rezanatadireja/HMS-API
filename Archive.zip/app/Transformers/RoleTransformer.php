<?php

namespace App\Transformers;

use League\Fractal\TransformerAbstract;
use App\Transformers\PermissionByRoleTransformer;

class RoleTransformer extends TransformerAbstract
{
    /**
     * List of resources to automatically include
     *
     * @var array
     */
    protected array $defaultIncludes = [
        //
    ];

    /**
     * List of resources possible to include
     *
     * @var array
     */
    protected array $availableIncludes = [
        //
    ];

    /**
     * A Fractal transformer.
     *
     * @return array
     */
    public function transform($data)
    {
        $permission  = fractal($data->permissions, new PermissionByRoleTransformer())->toArray();
        return [
			'id' => $data->id,
			'name' => $data->name,
            'permission'=>$permission['data']
		];
    }
}
