<?php namespace App\Constants;

class TransactionStatusConstants
{
    const REJECTED = 0;
    const APPROVED = 1;
    const APROVAL_PENDING = 2;
    const APROVAL_EDITED_PENDING = 3;
    const CANCELED = 99;

}
