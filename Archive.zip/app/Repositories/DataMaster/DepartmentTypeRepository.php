<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\DepartmentTypeInterface as DepartmentTypeInterface;
use App\Helpers\LogHelper;
use App\Models\DepartmentType;

class DepartmentTypeRepository implements DepartmentTypeInterface
{
    public function __construct(DepartmentType $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            $data = DepartmentType::create($request->validated());
            LogHelper::created_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil menambahkan tipe departemen ' . $data->name
        ];
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $data->update([
                'name' => $request->name,
                'code' => $request->code,
                'status' => $request->status
            ]);
            LogHelper::updated_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Melakukan perubahan pada tipe departemen ' . $data->name
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Menghapus Gedung ' . $data->name
        ];
    }

    public function status_update($request, $id)
    {
        $model = $this->model->findOrFail($id);
        try {
            if ($request->status == 1) {
                $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        LogHelper::updated_log($model);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
