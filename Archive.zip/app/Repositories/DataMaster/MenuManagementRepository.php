<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\MenuManagementInterface as MenuManagementInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use App\Models\Menu;
use App\Models\Log;
use App\Traits\ApiResponse;
use Illuminate\Support\Facades\DB;
use App\Helpers\LogHelper;

class MenuManagementRepository implements MenuManagementInterface
{
    public function __construct(Menu $model)
    {
        $this->model = $model;
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function tree()
    {
        $data = $this->model::all();

        $menuTree = Menu::toTree($data);

        return ['data' => $menuTree];
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        $rules = [
            'name' => 'required',
            'url' => 'required',
            'roles' => 'required',
        ];

        $message = [
            'name.required' => 'Kolom Nama wajib diisi',
            'url.required' => 'Kolom URL wajib diisi',
            'roles.required' => 'Silahkan tentukan role untuk menu yang dibuat'
        ];

        Validator::validate($request->all(), $rules, $message);
        try {
            DB::begintransaction();
            $menu = new Menu();
            $menu->name = $request->name;
            $menu->url = $request->url;
            $menu->icon = $request->icon;
            $menu->roles = $request->roles;
            $menu->is_service_menu = $request->is_service_menu;
            $menu->parent_id = empty($request->parent_id) ? Null : $request->parent_id;
            $menu->save();

            LogHelper::created_log($menu);
            DB::commit();
            return [
                'status' => true,
                'message' => 'Berhasil menambahkan Menu ' . $menu->name
            ];
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    public function update($id, $request)
    {
        try {
            DB::beginTransaction();
            $menu = $this->model::where('id', $id)->first();
            if (!$menu) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $menu->name = $request->name;
            $menu->url = $request->url;
            $menu->icon = $request->icon;
            $menu->roles = $request->roles;
            $menu->is_service_menu = $request->is_service_menu;
            $menu->parent_id = empty($request->parent_id) ? 0 : $request->parent_id;
            $menu->save();

            LogHelper::updated_log($menu);
            DB::commit();
            return [
                'status' => true,
                'message' => 'Berhasil Melakukan perubahan pada Menu ' . $menu->name
            ];
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Menghapus Menu ' . $data->name
        ];
    }
}
