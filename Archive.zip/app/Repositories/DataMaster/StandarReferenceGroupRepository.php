<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\StandarReferenceGroupInterface as StandarReferenceGroupInterface;
use Illuminate\Support\Facades\Validator;
use App\Models\StandarReferenceGroup;
use Illuminate\Support\Facades\DB;
use App\Helpers\LogHelper;
use Auth;

class StandarReferenceGroupRepository implements StandarReferenceGroupInterface
{
    public function __construct(StandarReferenceGroup $model)
    {
        $this->model = $model;
    }

    public function show($id)
    {
        $data = $this->model->findOrFail($id);

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        DB::beginTransaction();
        try {
            $model = $this->model->create($request->merge([
                'created_by' => Auth::user()->id,
                'updated_by' => Auth::user()->id
            ])->all());

            LogHelper::created_log($model);

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.created')
        ];
    }

    public function update($request, $id)
    {
        $model = $this->model->findOrFail($id);
        try {
            DB::beginTransaction();
            $model->update($request->validated());
            LogHelper::updated_log($model);
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.updated')
        ];
    }

    public function delete($id)
    {
        $model = $this->model->findOrFail($id);

        try {

            $model->delete();

            LogHelper::deleted_log($model);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'message' => config('constants.success.deleted'),
            'status' => true
        ];
    }
    public function status_update($request, $id)
    {
        $model = $this->model->findOrFail($id);

        try {
            if ($request->status == 1) {
                $model = $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $model = $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
