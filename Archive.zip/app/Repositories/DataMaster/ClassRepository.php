<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\ClassInterface as ClassInterface;
use App\Helpers\LogHelper;
use App\Models\Classs;
use Illuminate\Support\Facades\DB;

class ClassRepository implements ClassInterface
{
    public function __construct(Classs $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            $data = Classs::create($request->validated());
            LogHelper::created_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.created')
        ];
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();
        return $data;
    }

    public function update($request, $id)
    {
        try {
            DB::beginTransaction();
            $data = $this->model::where('id', $id)->first();

            $data->update($request->validated());
            LogHelper::updated_log($data);
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'status' => false,
                'message' => "Data tidak ditemukan.",
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.updated')
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'status' => false,
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.deleted')
        ];
    }

    public function status_update($request, $id)
    {
        $model = $this->model->findOrFail($id);
        try {
            if ($request->status == 1) {
                $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => "gagal"
            ];
        }

        LogHelper::updated_log($model);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
