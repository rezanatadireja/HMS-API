<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\AppParameterInterface as AppParameterInterface;
use App\Models\Building;
use App\Helpers\LogHelper;
use App\Models\AppParameter;
use Illuminate\Support\Facades\DB;

class AppParameterRepository implements AppParameterInterface
{
    public function __construct(AppParameter $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        if (!$data) {
            return [
                'status' => false,
                'message' => 'Data Tidak Ditemukan'
            ];
        }

        return [
            'status' => true,
            'data' => $data
        ];
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            DB::beginTransaction();
            $appParameter = AppParameter::create($request->validated());
            LogHelper::created_log($appParameter);
            DB::commit();
            return [
                'status' => true,
                'message' => 'Berhasil Menambahkan App Parameter ' . $appParameter->name
            ];
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    public function update($request, $id)
    {
        try {
            DB::beginTransaction();
            $data = $this->model->where('id', $id)->first();
            $data->fill($request->validated())->save();
            LogHelper::updated_log($data);
            DB::commit();
            return [
                'status' => true,
                'message' => 'Berhasil Melakukan Perubahan Pada App Parameter ' . $data->name
            ];
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'status' => false,
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
            return [
                'status' => true,
                'message' => 'Berhasil Menghapus App Parameter ' . $data->name
            ];
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }
}
