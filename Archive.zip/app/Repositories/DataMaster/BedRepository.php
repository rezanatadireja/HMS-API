<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\BedInterface as BedInterface;
use App\Models\Bed;
use App\Helpers\LogHelper;

class BedRepository implements BedInterface
{
    public function __construct(Bed $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'ilike', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            $bed = Bed::create($request->validated());
            LogHelper::created_log($bed);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil menambahkan bed ' . $bed->name
        ];
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();
        if (!$data) {
            return [
                'status' => 'error',
                'message' => 'Data Tidak Ditemukan'
            ];
        }
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $bed = $this->model::where('id', $id)->first();
            
            if (!$bed) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $bed->update([
                'room_id' => $request->room_id,
                'ref_bed_status' => $request->ref_bed_status,
                'old_bed_id' => $request->old_bed_id,
                'default_charge_class_id' => $request->default_charge_class_id,
                'registration_no' => $request->registration_no,
                'bed_status_updated_by' => $request->bed_status_updated_by,
                'is_temporary' => $request->is_temporary,
                'is_need_confirmation' => $request->is_need_confirmation,
                'is_room_in' => $request->is_room_in,
                'booking_date_time' => $request->booking_date_time,
                'is_visible_3rd_party' => $request->is_visible_3rd_party,
                'notes' => $request->notes,
                'owner_user_id' => $request->owner_user_id,
                'status' => $request->status
            ]);
            LogHelper::updated_log($bed);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Melakukan perubahan pada bed ' . $bed->name
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Menghapus bed ' . $data->name
        ];
    }

    public function status_update($request, $id)
    {
        $data = $this->model::where('id', $id)->first();
        if (!$data) {
            return [
                'status' => 'error',
                'message' => 'Data Tidak Ditemukan'
            ];
        }
        try {
            if ($request->status == 1) {
                $model = $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $model = $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        LogHelper::updated_log($data);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
