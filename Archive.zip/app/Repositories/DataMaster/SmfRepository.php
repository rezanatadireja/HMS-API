<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\SmfInterface as SmfInterface;
use App\Helpers\LogHelper;
use App\Models\Smf;

class SmfRepository implements SmfInterface
{
    public function __construct(Smf $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            $data = Smf::create($request->validated());
            LogHelper::created_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.created')
        ];
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->update([
                'ref_paramedic_fee_cash_type' => $request->ref_paramedic_fee_cash_type,
                'ref_assesment_type' => $request->ref_assesment_type,
                'name' => $request->name,
                'status' => $request->status,
            ]);
            LogHelper::updated_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.updated')
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.deleted')
        ];
    }

    public function status_update($request, $id)
    {
        $model = $this->model->findOrFail($id);
        try {
            if ($request->status == 1) {
                $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => "gagal"
            ];
        }

        LogHelper::updated_log($model);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
