<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\ParamedicScheduleInterface as ParamedicScheduleInterface;
use App\Models\ParamedicSchedule;
use App\Helpers\LogHelper;

class ParamedicScheduleRepository implements ParamedicScheduleInterface
{
    public function __construct(ParamedicSchedule $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('paramedic_id', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            $paramedicSchedule = ParamedicSchedule::create($request->validated());
            LogHelper::created_log($paramedicSchedule);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil menambahkan paramedic schedule ' . $paramedicSchedule->paramedic_id
        ];
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $paramedicSchedule = $this->model::where('id', $id)->first();
            
            if (!$paramedicSchedule) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $paramedicSchedule->update([
                'paramedic_id' => $request->paramedic_id,
                'service_unit_id' => $request->service_unit_id,
                'period_year' => $request->period_year,
                'exam_duration' => $request->exam_duration,
                'notes' => $request->notes,
                'quota' => $request->quota,
                'quota_online' => $request->quota_online,
                'quota_bpjs' => $request->quota_bpjs,
                'quota_bpjs_online' => $request->quota_bpjs_online,
                'owner_user_id' => $request->owner_user_id

            ]);
            LogHelper::updated_log($paramedicSchedule);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Melakukan perubahan pada paramedic schedule ' . $paramedicSchedule->paramedic_id
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Menghapus paramedic schedule ' . $data->paramedic_id
        ];
    }

    public function status_update($id, $request)
    {
        $$model = $this->model->findOrFail($id);
        try {
            if ($request->status == 1) {
                $model = $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $model = $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        LogHelper::updated_log($model);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
