<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\ItemInterface as ItemInterface;
use App\Models\Building;
use App\Helpers\LogHelper;
use App\Models\Item;
use Illuminate\Support\Facades\DB;

class ItemRepository implements ItemInterface
{
    public function __construct(Item $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        if (!$data) {
            return [
                'status' => false,
                'message' => 'Data Tidak Ditemukan'
            ];
        }

        return [
            'status' => true,
            'data' => $data
        ];
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            DB::beginTransaction();
            $data = Item::create($request->validated());
            LogHelper::created_log($data);
            DB::commit();
            return [
                'status' => true,
                'message' => config('constants.success.created') . $data->name
            ];
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    public function update($request, $id)
    {
        try {
            DB::beginTransaction();
            $data = $this->model->where('id', $id)->first();
            $data->fill($request->validated())->save();
            LogHelper::updated_log($data);
            DB::commit();
            return [
                'status' => true,
                'message' => config('constants.success.updated') . $data->name
            ];
        } catch (\Exception $e) {
            DB::rollBack();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'status' => false,
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
            return [
                'status' => true,
                'message' => config('constants.success.deleted') . $data->name
            ];
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    public function status_update($request, $id)
    {
        $model = $this->model->findOrFail($id);
        try {
            if ($request->status == 1) {
                $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => "gagal"
            ];
        }

        LogHelper::updated_log($model);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
