<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\StandarReferenceInterface as StandarReferenceInterface;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;
use App\Models\StandarReference;
use App\Models\Log;
use LogHelper, DB, Auth, Validator;

class StandarReferenceRepository implements StandarReferenceInterface
{
    public function __construct(StandarReference $model)
    {
        $this->model = $model;
    }

    public function show($id)
    {
        $data = $this->model->findOrFail($id);

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->with('standarReferenceGroup');
        $kw = $request->keyword;

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }
        $query->whereHas('standarReferenceGroup', function ($q) use ($kw) {
            $q->where('name', 'like', "%{$kw}%");
        });

        return $query->get();
    }

    public function store($request)
    {
        $rules = [
            'name' => 'required',
            'code' => 'required',
            'standar_reference_group_id' => 'required',
        ];

        $message = [
            'name.required' => 'Kolom Nama wajib diisi',
            'code.required' => 'Kolom Kode Standar Reference wajib diisi',
            'standar_reference_group_id' => 'Pilih Standar Reference Group Terlebih dahulu'
        ];

        Validator::validate($request->all(), $rules, $message);

        DB::beginTransaction();
        try {
            $model = $this->model->create($request->all());

            $model->standarReferenceItem()->createMany($request->items);

            LogHelper::created_log($model);

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.created')
        ];
    }

    public function update($request, $id)
    {
        $rules = [
            'name' => 'required',
            'code' => 'required',
            'standar_reference_group_id' => 'required'
        ];

        $message = [
            'name.required' => 'Kolom Nama wajib diisi',
            'code.required' => 'Kolom Kode Standar Reference wajib diisi',
            'standar_reference_group_id' => 'Pilih Standar Reference Group Terlebih dahulu'
        ];

        Validator::validate($request->all(), $rules, $message);
        DB::beginTransaction();
        try {

            $model = $this->model->findOrFail($id);

            $model->update($request->all());

            DB::commit();
            LogHelper::updated_log($model);
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.updated')
        ];
    }

    public function delete($id)
    {
        $model = $this->model->findOrFail($id);

        try {

            $model->delete();

            LogHelper::deleted_log($model);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'message' => config('constants.success.deleted'),
            'status' => true
        ];
    }
    public function status_update($request, $id)
    {
        $model = $this->model->findOrFail($id);

        try {
            if ($request->status == 1) {
                $model = $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $model = $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
