<?php

namespace App\Repositories\DataMaster;

use Illuminate\Support\ServiceProvider;

class DataMasterRepoServiceProvider extends ServiceProvider
{
    public function boot() {}

    public function register()
    {
        $this->app->bind(
            'App\Interfaces\DataMaster\MenuManagementInterface',
            'App\Repositories\DataMaster\MenuManagementRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\StandarReferenceGroupInterface',
            'App\Repositories\DataMaster\StandarReferenceGroupRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\MenuManagementInterface',
            'App\Repositories\DataMaster\MenuManagementRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\BuildingInterface',
            'App\Repositories\DataMaster\BuildingRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\StandarReferenceInterface',
            'App\Repositories\DataMaster\StandarReferenceRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\StandarReferenceItemInterface',
            'App\Repositories\DataMaster\StandarReferenceItemRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\DepartmentTypeInterface',
            'App\Repositories\DataMaster\DepartmentTypeRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\FloorInterface',
            'App\Repositories\DataMaster\FloorRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\AppParameterInterface',
            'App\Repositories\DataMaster\AppParameterRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\SmfInterface',
            'App\Repositories\DataMaster\SmfRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\ClassInterface',
            'App\Repositories\DataMaster\ClassRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\HealthServiceProviderInterface',
            'App\Repositories\DataMaster\HealthServiceProviderRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\ItemInterface',
            'App\Repositories\DataMaster\ItemRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\ItemGroupInterface',
            'App\Repositories\DataMaster\ItemGroupRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\DepartmentInterface',
            'App\Repositories\DataMaster\DepartmentRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\ServiceRoomInterface',
            'App\Repositories\DataMaster\ServiceRoomRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\BedInterface',
            'App\Repositories\DataMaster\BedRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\ParamedicInterface',
            'App\Repositories\DataMaster\ParamedicRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\ParamedicScheduleInterface',
            'App\Repositories\DataMaster\ParamedicScheduleRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\ParamedicScheduleDateInterface',
            'App\Repositories\DataMaster\ParamedicScheduleDateRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\OperationalTimeInterface',
            'App\Repositories\DataMaster\OperationalTimeRepository'
        );

        $this->app->bind(
            'App\Interfaces\DataMaster\LocationInterface',
            'App\Repositories\DataMaster\LocationRepository'
        );
    }
}
