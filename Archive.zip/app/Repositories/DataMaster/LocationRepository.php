<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\LocationInterface as LocationInterface;
use App\Models\Location;
use App\Helpers\LogHelper;

class LocationRepository implements LocationInterface
{
    public function __construct(Location $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            $location = Location::create($request->validated());
            LogHelper::created_log($location);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil menambahkan location ' . $location->name
        ];
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $location = $this->model::where('id', $id)->first();
            
            if (!$location) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $location->update([
                'parent_id' => $request->parent_id,
                'item_group_id' => $request->item_group_id,
                'permit_id' => $request->permit_id,
                'ref_type_of_inventory' => $request->ref_type_of_inventory,
                'ref_stock_group' => $request->ref_stock_group,
                'chart_of_account_id_income' => $request->chart_of_account_id_income,
                'subledger_id_income' => $request->subledger_id_income,
                'chart_of_account_id_inventory' => $request->chart_of_account_id_inventory,
                'chart_of_account_id_cogs' => $request->chart_of_account_id_cogs,
                'subledger_id_cogs' => $request->subledger_id_cogs,
                'chart_of_account_id_sales_return' => $request->chart_of_account_id_sales_return,
                'subledger_id_sales_return' => $request->subledger_id_sales_return,
                'chart_of_account_id_purchase_return' => $request->chart_of_account_id_purchase_return,
                'subledger_id_purchase_return' => $request->subledger_id_purchase_return,
                'chart_of_account_id_acrual' => $request->chart_of_account_id_acrual,
                'subledger_id_acrual' => $request->subledger_id_acrual,
                'chart_of_account_id_discount' => $request->chart_of_account_id_discount,
                'subledger_id_discount' => $request->subledger_id_discount,
                'chart_of_account_id_cost' => $request->chart_of_account_id_cost,
                'subledger_id_cost' => $request->subledger_id_cost,
                'name' => $request->name,
                'short_name' => $request->short_name,
                'is_header' => $request->is_header,
                'is_hold_for_transaction' => $request->is_hold_for_transaction,
                'is_allowed_to_stock_goods' => $request->is_allowed_to_stock_goods,
                'is_consignment' => $request->is_consignment,
                'is_validate_max_value_on_dist_req_for_ipm' => $request->is_validate_max_value_on_dist_req_for_ipm,
                'is_validate_max_value_on_dist_req_for_ipnm' => $request->is_validate_max_value_on_dist_req_for_ipnm,
                'is_validate_max_value_on_dist_req_for_ik' => $request->is_validate_max_value_on_dist_req_for_ik,
                'is_validate_max_value_on_purc_req_for_ipm' => $request->is_validate_max_value_on_purc_req_for_ipm,
                'is_validate_max_value_on_purc_req_for_ipnm' => $request->is_validate_max_value_on_purc_req_for_ipnm,
                'is_validate_max_value_on_purc_req_for_ik' => $request->is_validate_max_value_on_purc_req_for_ik,
                'last_hold_for_transaction_date_time' => $request->last_hold_for_transaction_date_time,
                'last_hold_for_transaction_by_user_id' => $request->last_hold_for_transaction_by_user_id,
                'is_auto_update_stock_min_max' => $request->is_auto_update_stock_min_max,
                'status' => $request->status,
                'owner_user_id' => $request->owner_user_id
            ]);
            LogHelper::updated_log($location);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Melakukan perubahan pada location ' . $location->name
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Menghapus location ' . $data->name
        ];
    }

    public function status_update($id, $request)
    {
        $$model = $this->model->findOrFail($id);
        try {
            if ($request->status == 1) {
                $model = $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $model = $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        LogHelper::updated_log($model);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
