<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\ParamedicScheduleDateInterface as ParamedicScheduleDateInterface;
use App\Models\ParamedicScheduleDate;
use App\Helpers\LogHelper;

class ParamedicScheduleDateRepository implements ParamedicScheduleDateInterface
{
    public function __construct(ParamedicScheduleDate $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('paramedic_id', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            $paramedicScheduleDate = ParamedicScheduleDate::create($request->validated());
            LogHelper::created_log($paramedicScheduleDate);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil menambahkan paramedic schedule date ' . $paramedicScheduleDate->paramedic_id
        ];
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $paramedicScheduleDate = $this->model::where('id', $id)->first();
            
            if (!$paramedicScheduleDate) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $paramedicScheduleDate->update([
                'service_unit_id' => $request->service_unit_id,
                'paramedic_id' => $request->paramedic_id,
                'operational_time_id' => $request->operational_time_id,
                'period_year' => $request->period_year,
                'schedule_date' => $request->schedule_date,
                'is_closed_time_1' => $request->is_closed_time_1,
                'losed_time_1' => $request->losed_time_1,
                'closed_time_1_by_user_id' => $request->closed_time_1_by_user_id,
                'is_closed_time_2' => $request->is_closed_time_2,
                'losed_time_2' => $request->losed_time_2,
                'closed_time_2_by_user_id' => $request->closed_time_2_by_user_id,
                'is_closed_time_3' => $request->is_closed_time_3,
                'losed_time_3' => $request->losed_time_3,
                'closed_time_3_by_user_id' => $request->closed_time_3_by_user_id,
                'is_closed_time_4' => $request->is_closed_time_4,
                'losed_time_4' => $request->losed_time_4,
                'closed_time_4_by_user_id' => $request->closed_time_4_by_user_id,
                'is_closed_time_5' => $request->is_closed_time_5,
                'losed_time_5' => $request->losed_time_5,
                'closed_time_5_by_user_id' => $request->closed_time_5_by_user_id,
                'is_ipr' => $request->is_ipr,
                'is_opr' => $request->is_opr,
                'is_emr' => $request->is_emr,
                'period_month' => $request->period_month,
                'add_quota' => $request->add_quota,
                'add_quota_online' => $request->add_quota_online,
                'add_quota_bpjs' => $request->add_quota_bpjs,
                'add_quota_bpjs_online' => $request->add_quota_bpjs_online,
                'owner_user_id' => $request->owner_user_id
            ]);
            LogHelper::updated_log($paramedicScheduleDate);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Melakukan perubahan pada paramedic schedule date date ' . $paramedicScheduleDate->paramedic_id
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Menghapus paramedic schedule date date ' . $data->paramedic_id
        ];
    }

    public function status_update($id, $request)
    {
        $$model = $this->model->findOrFail($id);
        try {
            if ($request->status == 1) {
                $model = $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $model = $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        LogHelper::updated_log($model);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
