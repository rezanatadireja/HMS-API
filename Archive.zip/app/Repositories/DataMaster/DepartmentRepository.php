<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\DepartmentInterface as DepartmentInterface;
use App\Models\Department;
use App\Helpers\LogHelper;

class DepartmentRepository implements DepartmentInterface
{
    public function __construct(Department $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();
        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();
        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('departments.name', 'ilike', "%{$request->keyword}%");
        }
        return $query
                ->join('department_types', 'departments.department_type_id', '=', 'department_types.id')
                ->join('buildings', 'departments.building_id', '=', 'buildings.id')
                ->join('floors', 'departments.floor_id', '=', 'floors.id')
                ->select
                (
                'departments.*', 
                'department_types.name as department_type_name',
                'buildings.name as building_name',
                'floors.name as floor_name',
                )
                ->get();
    }

    public function store($request)
    {
        try {
            $department = Department::create($request->validated());
            LogHelper::created_log($department);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil menambahkan department ' . $department->name
        ];
    }

    public function show($id)
    {
        $query = $this->model->query();
        $data = $query
                ->join('department_types', 'departments.department_type_id', '=', 'department_types.id')
                ->join('buildings', 'departments.building_id', '=', 'buildings.id')
                ->join('floors', 'departments.floor_id', '=', 'floors.id')
                ->select
                (
                'departments.*', 
                'department_types.name as department_type_name',
                'buildings.name as building_name',
                'floors.name as floor_name',
                )
                ->where('departments.id', '=', $id)
                ->first();
        if (!$data) {
            return [
                'status' => 'error',
                'message' => 'Data Tidak Ditemukan'
            ];
        }
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $department = $this->model::where('id', $id)->first();
            if (!$department) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $department->update([
                'department_type_id' => $request->department_type_id,
                'parent_id' => $request->parent_id,
                'building_id' => $request->building_id,
                'floor_id' => $request->floor_id,
                'name' => $request->name,
                'short_name' => $request->short_name,
                'code' => $request->code,
                'is_using_job_order' => $request->is_using_job_order,
                'is_patient_transaction' => $request->is_patient_transaction,
                'is_dispensary_unit' => $request->is_dispensary_unit,
                'is_purchasing_unit' => $request->is_purchasing_unit,
                'status' => $request->status
            ]);
            LogHelper::updated_log($department);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Melakukan perubahan pada department ' . $department->name
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Menghapus department ' . $data->name
        ];
    }

    public function status_update($request, $id)
    {
        $data = $this->model::where('id', $id)->first();
        if (!$data) {
            return [
                'status' => 'error',
                'message' => 'Data Tidak Ditemukan'
            ];
        }
        try {
            if ($request->status == 1) {
                $result = $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $result = $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        LogHelper::updated_log($data);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
