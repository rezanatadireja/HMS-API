<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\ServiceRoomInterface as ServiceRoomInterface;
use App\Models\ServiceRoom;
use App\Helpers\LogHelper;

class ServiceRoomRepository implements ServiceRoomInterface
{
    public function __construct(ServiceRoom $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('service_rooms.name', 'ilike', "%{$request->keyword}%");
        }
        return $query
                ->join('departments', 'service_rooms.department_id', '=', 'departments.id')
                ->join('floors', 'service_rooms.floor_id', '=', 'floors.id')
                ->select
                (
                'service_rooms.*', 
                'departments.name as department_name',
                'floors.name as floor_name',
                )
                ->get();
    }

    public function store($request)
    {
        try {
            $serviceRoom = ServiceRoom::create($request->validated());
            LogHelper::created_log($serviceRoom);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil menambahkan service room ' . $serviceRoom->name
        ];
    }

    public function show($id)
    {
        // $data = $this->model::where('id', $id)->first();
        // return $data;
        $query = $this->model->query();
        $data = $query
                ->join('departments', 'service_rooms.department_id', '=', 'departments.id')
                ->join('floors', 'service_rooms.floor_id', '=', 'floors.id')
                ->select
                (
                'service_rooms.*', 
                'departments.name as department_name',
                'floors.name as floor_name',
                )
                ->where('service_rooms.id', '=', $id)
                ->first();
        if (!$data) {
            return [
                'status' => 'error',
                'message' => 'Data Tidak Ditemukan'
            ];
        }
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $serviceRoom = $this->model::where('id', $id)->first();
            
            if (!$serviceRoom) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $serviceRoom->update([
                'department_id' => $request->department_id,
                'floor_id' => $request->floor_id,
                'ref_gender_type' => $request->ref_gender_type,
                'name' => $request->name,
                'is_operation_room' => $request->is_operation_room,
                'is_bpjs' => $request->is_bpjs,
                'is_isolation_room' => $request->is_isolation_room,
                'is_negative_pressure_room' => $request->is_negative_pressure_room,
                'is_pandemic_room' => $request->is_pandemic_room,
                'is_ventilator' => $request->is_ventilator,
                'notes' => $request->notes,
                'status' => $request->status,
                'owner_user_id' => $request->owner_user_id,
            ]);
            LogHelper::updated_log($serviceRoom);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Melakukan perubahan pada service room ' . $serviceRoom->name
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Menghapus service room ' . $data->name
        ];
    }

    public function status_update($request, $id)
    {
        $data = $this->model::where('id', $id)->first();
        if (!$data) {
            return [
                'status' => 'error',
                'message' => 'Data Tidak Ditemukan'
            ];
        }
        try {
            if ($request->status == 1) {
                $result = $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $result = $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        LogHelper::updated_log($data);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
