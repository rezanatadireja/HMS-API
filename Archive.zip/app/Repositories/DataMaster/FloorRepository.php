<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\FloorInterface as FloorInterface;
use App\Helpers\LogHelper;
use App\Models\Floor;

class FloorRepository implements FloorInterface
{
    public function __construct(Floor $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'like', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            $data = Floor::create($request->validated());
            LogHelper::created_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.created')
        ];
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $data->update([
                'name' => $request->name,
                'code' => $request->code,
                'status' => $request->status,
            ]);
            LogHelper::updated_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $request->all(),
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.updated')
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'message' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => config('constants.success.deleted')
        ];
    }

    public function status_update($request, $id)
    {
        $model = $this->model->findOrFail($id);
        if (!$model) {
            return [
                'status' => false,
                'message' => 'Data Tidak Ditemukan'
            ];
        }
        try {
            if ($request->status == 1) {
                $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        LogHelper::updated_log($model);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
