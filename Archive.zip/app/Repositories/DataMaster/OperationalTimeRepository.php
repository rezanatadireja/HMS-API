<?php

namespace App\Repositories\DataMaster;

use App\Interfaces\DataMaster\OperationalTimeInterface as OperationalTimeInterface;
use App\Models\OperationalTime;
use App\Helpers\LogHelper;

class OperationalTimeRepository implements OperationalTimeInterface
{
    public function __construct(OperationalTime $model)
    {
        $this->model = $model;
    }

    public function findById($id)
    {
        $data = $this->model::where('id', $id)->first();

        return $data;
    }

    public function data($request)
    {
        $query = $this->model->query();

        if ($request->has('keyword') && !empty($request->keyword)) {
            $query->where('name', 'ilike', "%{$request->keyword}%");
        }

        return $query->get();
    }

    public function store($request)
    {
        try {
            $operationalTime = OperationalTime::create($request->validated());
            LogHelper::created_log($operationalTime);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil menambahkan operational time ' . $operationalTime->name
        ];
    }

    public function show($id)
    {
        $data = $this->model::where('id', $id)->first();
        if (!$data) {
            return [
                'status' => 'error',
                'message' => 'Data Tidak Ditemukan'
            ];
        }
        return $data;
    }

    public function update($request, $id)
    {
        try {
            $operationalTime = $this->model::where('id', $id)->first();
            
            if (!$operationalTime) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }

            $operationalTime->update([
                'name' => $request->name,
                'start_time_1' => $request->start_time_1,
                'end_time_1' => $request->end_time_1,
                'start_time_2' => $request->start_time_2,
                'end_time_2' => $request->end_time_2,
                'start_time_3' => $request->start_time_3,
                'end_time_3' => $request->end_time_3,
                'start_time_4' => $request->start_time_4,
                'end_time_4' => $request->end_time_4,
                'start_time_5' => $request->start_time_5,
                'end_time_5' => $request->end_time_5,
                'time_back_color' => $request->time_back_color,
                'owner_user_id' => $request->owner_user_id
            ]);
            LogHelper::updated_log($operationalTime);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Melakukan perubahan pada operational time ' . $operationalTime->name
        ];
    }

    public function delete($id)
    {
        try {
            $data = $this->model::where('id', $id)->first();

            if (!$data) {
                return [
                    'status' => 'error',
                    'message' => 'Data Tidak Ditemukan'
                ];
            }
            $data->delete();

            LogHelper::deleted_log($data);
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }
        return [
            'status' => true,
            'message' => 'Berhasil Menghapus operational time ' . $data->name
        ];
    }

    public function status_update($request, $id)
    {
        $model = $this->model->findOrFail($id);
        if (!$model) {
            return [
                'status' => 'error',
                'message' => 'Data Tidak Ditemukan'
            ];
        }
        try {
            if ($request->status == 1) {
                $model = $this->model->where('id', $id)->Activate();
                $constantMessage = 'activate';
            } else {
                $model = $this->model->where('id', $id)->Deactivate();
                $constantMessage = 'deactivate';
            }
        } catch (\Exception $e) {
            return [
                'status' => false,
                'message' => $e->getMessage()
            ];
        }

        LogHelper::updated_log($model);
        return [
            'message' => config('constants.success.' . $constantMessage),
            'status' => true
        ];
    }
}
