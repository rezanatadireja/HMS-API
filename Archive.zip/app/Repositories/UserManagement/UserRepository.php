<?php

namespace App\Repositories\UserManagement;

use App\Interfaces\UserManagement\UserInterface as UserInterface;
use Carbon\Carbon;
use App\Models\Role;
use App\Models\User;
use App\Models\Permission;
use App\Models\Log;
use Illuminate\Hashing\BcryptHasher;
use LogHelper, Auth, Validator, DB, Hash;

class UserRepository implements UserInterface
{
    public function __construct(User $model)
    {
        $this->model = $model;
    }

    public function data($request)
    {
        $query = $this->model->query();

		if($request->has('keyword') && !empty($request->keyword)){
			$query->where('name', 'like', "%{$request->keyword}%");
		}

		return $query->get();
    }


    public function show($id)
    {
		$data =  $this->model->findOrFail($id);

		return $data;
	}

    public function create($request)
    {
        $rules = [
            'name' => 'required',
            'username' => 'required',
            'email' => 'required|unique:users|email',
            'password' => 'required|min:6',
        ];

        $message = [
            'name.required' => 'Kolom Nama wajib diisi',
            'username.required' => 'Kolom User Nama wajib diisi',
            'email.required' => 'Kolom Email wajib diisi',
            'email.unique' => 'Email sudah terdaftar',
            'email.email' => 'Format yang anda masukan salah',
            'password.required' => 'Kolom Password wajib diisi',
            'password.min' => 'Password harus memiliki minimal 6 karakter',
        ];

        Validator::validate($request->all(), $rules, $message);

        DB::beginTransaction();
        try {

            $model = new User();
            $model->email = $request->email;
            $model->name = $request->name;
            $model->username = $request->name;
            // if ($request->filled('employee_id')) {
            //     $store->employee_id = $request->get('employee_id');
            // }
            $model->password =  Hash::make($request->password);
            $model->status =  1;
            $model->save();

            $roles = $request->roles;

            if (isset($roles)) {

                foreach ($roles as $role) {
                $role_r = Role::where('id', '=', $role)->firstOrFail();
                $model->assignRole($role_r);
                }
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }

        LogHelper::created_log($model);
		return [
			'message' => config('constants.success.created'),
			'status' => true
		];
    }
    public function update($request, $id)
    {
        $rules = [
            'name' => 'required',
            'username' => 'required',
            'email' => 'required|email',

        ];

        $message = [
            'name.required' => 'Kolom Nama wajib diisi',
            'username.required' => 'Kolom User Nama wajib diisi',
            'email.required' => 'Kolom Email wajib diisi',
            'email.email' => 'Format yang anda masukan salah',

        ];

        Validator::validate($request->all(), $rules, $message);

        DB::beginTransaction();
        try {

            $model = $this->model->findOrFail($id);

            $roles = $request->roles;

            $model->email = $request->email;

            $model->name = $request->name;

            $model->username = $request->username;

            $password = $request->password;

            if (isset($password) == true) {
                $model->password = Hash::make($password);
            }

            $model->save();

            if (isset($roles)) {
                $model->roles()->sync($roles);
            }
            else {
                $model->roles()->detach();
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }

        LogHelper::updated_log($model);
		return [
			'message' => config('constants.success.updated'),
			'status' => true
		];
    }
    public function delete($id)
    {
        $model = $this->model->findOrFail($id);

        try {
            $model->delete();
        } catch (\Exception $e) {
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }
        LogHelper::deleted_log($model);
        return [
			'message' => config('constants.success.deleted'),
			'status' => true
		];
	}

    public function change_password($request,$id)
    {
        $rules = [
            'old_password'=>'required|string|min:8',
            'new_password'=>'required|string|min:8|different:old_password',
            'password_confirmation'=>'required_with:new_password|same:new_password|string|min:8'
        ];

        $message = [
            'new_password.required' => 'Kolom Kata Sandi Baru wajib diisi',
            'password_confirmation.same'=>'Kolom Konfirmasi Kata Sandi harus sesuai dengan kolom kata sandi baru',
        ];

        Validator::validate($request->only('old_password','new_password','password_confirmation'), $rules, $message);

        try {
            $validation_password = Hash::check($request->old_password, Auth::user()->password);
            if(!$validation_password){
                return [
                    'message'=>'Kata Sandi lama tidak valid',
                    'status'=>false
                ];
            } else {
                $model = $this->model->findOrFail($id);
                $model->password = (new BcryptHasher)->make($request->new_password);

                if ($model->save()) {
                    return [
                        'message'=>'Kata Sandi anda berhasil diganti',
                        'status'=>true
                    ];
                } else {
                    return[
                        'message'=>'Kata Sandi yang anda masukkan tidak valid',
                        'status'=>false
                    ];
                }
            }
        } catch (\Exception $e) {
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }

	}
}
