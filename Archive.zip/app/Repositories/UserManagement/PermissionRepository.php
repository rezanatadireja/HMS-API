<?php

namespace App\Repositories\UserManagement;

use App\Interfaces\UserManagement\PermissionInterface as PermissionInterface;
use App\Transformers\PermissionByUserTransformer;
use Carbon\Carbon;
use App\Models\Role;
use App\Models\User;
use App\Models\Permission;
use App\Models\Log;
use LogHelper, Auth, Validator, DB;

class PermissionRepository implements PermissionInterface
{
    public function __construct(Permission $model)
    {
        $this->model = $model;
    }

    public function data($request)
    {
        $query = $this->model->query();

		if($request->has('keyword') && !empty($request->keyword)){
			$query->where('name', 'like', "%{$request->keyword}%");
		}

		return $query->get();
    }

    public function show_permission_by_user($id)
    {
        $user = User::findOrFail($id);

        $response = fractal($user->getPermissionsViaRoles(), new PermissionByUserTransformer())->toArray();

		return $response;
    }

    public function show($id)
    {
		$data =  $this->model->findOrFail($id);

		return $data;
	}

    public function create($request)
    {
        $rules = [
            'name' => 'required',
        ];

        $message = [
            'name.required' => 'Kelompok Tagihan wajib diisi',
        ];

        Validator::validate($request->all(), $rules, $message);

        DB::beginTransaction();
        try {

            $model = $this->model->create($request->all());

            if (!empty($request->roles)) { //If one or more role is selected
                foreach ($request->roles as $role) {
                    $r = Role::where('id', '=', $role)->firstOrFail(); //Match input role to db record
                    $store = Permission::where('name', '=', $name)->first(); //Match input //permission to db record
                    $r->givePermissionTo($store);
                }
            }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }

        LogHelper::created_log($model);
		return [
			'message' => config('constants.success.created'),
			'status' => true
		];
    }
    public function update($request, $id)
    {
        $rules = [
            'name' => 'required',
        ];

        $message = [
            'name.required' => 'Kelompok tagihan wajib diisi',
        ];

        Validator::validate($request->all(), $rules, $message);

        DB::beginTransaction();
        try {
            $model = $this->model->findOrFail($id);

            $model->update($request->merge([
                'updated_by' => Auth::user()->id
			])->all());

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }

        LogHelper::updated_log($model);
		return [
			'message' => config('constants.success.updated'),
			'status' => true
		];
    }
    public function delete($id)
    {
        $model = $this->model->findOrFail($id);

        try {
            $model->delete();
        } catch (\Exception $e) {
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }
        LogHelper::deleted_log($model);
        return [
			'message' => config('constants.success.deleted'),
			'status' => true
		];
	}

    public function generate($request)
    {

        try {

            $model = \Artisan::call('auth:permission '.$request->module);
            switch ($model) {
                case 0:
                    $message = 'permissiongeneratesuccess';
                    break;
                case 1:
                    $message = 'permissiongeneratefailed';
                    break;
                case 2:
                    $message = 'permissiongenerateinvalid';
                    break;

                default:
                    # code...
                    break;
            }

        } catch (\Exception $e) {
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }

        return [
			'message' => config('constants.success.'.$message),
			'status' => $message == 0 ? false:true
		];
	}

    public function reset($request)
    {

        try {

            $model = \Artisan::call('cache:forget spatie.permission.cache');
            switch ($model) {
                case 0:
                    $message = 'cache reset successfully';
                    break;
                case 1:
                    $message = 'cache reset failed';
                    break;
                case 2:
                    $message = 'invalid command';
                    break;

                default:
                    $message = 'Error Yang Tidak Diketahui';
                    break;
            }

        } catch (\Exception $e) {
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }

        return [
			'message' => $message,
			'status' => $message == 0 ? false:true
		];
	}


}


