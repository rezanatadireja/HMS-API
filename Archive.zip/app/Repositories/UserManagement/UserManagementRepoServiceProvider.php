<?php
namespace App\Repositories\UserManagement;
use Illuminate\Support\ServiceProvider;

class UserManagementRepoServiceProvider extends ServiceProvider
{
    public function boot(){}

    public function register()
    {
        $this->app->bind('App\Interfaces\UserManagement\UserInterface',
        'App\Repositories\UserManagement\UserRepository');

        $this->app->bind('App\Interfaces\UserManagement\RoleInterface',
        'App\Repositories\UserManagement\RoleRepository');

        $this->app->bind('App\Interfaces\UserManagement\PermissionInterface',
        'App\Repositories\UserManagement\PermissionRepository');

    }
}
