<?php

namespace App\Repositories\UserManagement;

use App\Interfaces\UserManagement\RoleInterface as RoleInterface;
use Carbon\Carbon;
use App\Models\Role;
use App\Models\User;
use App\Models\Permission;
use App\Models\Log;
use LogHelper, Auth, Validator, DB;

class RoleRepository implements RoleInterface
{
    public function __construct(Role $model)
    {
        $this->model = $model;
    }

    public function data($request)
    {
        $query = $this->model->query();

		if($request->has('keyword') && !empty($request->keyword)){
			$query->where('name', 'like', "%{$request->keyword}%");
		}

		return $query->get();
    }


    public function show($id)
    {
		$data =  $this->model->findOrFail($id);

		return $data;
	}

    public function create($request)
    {
        $rules = [
            'name' => 'required',
        ];

        $message = [
            'name.required' => 'Nama Role wajib diisi',
        ];

        Validator::validate($request->all(), $rules, $message);

        DB::beginTransaction();
        try {

            $model = $this->model->create($request->all());
            $name = $model->name;
            foreach ($request->permissions as $permission) {
                $p = Permission::where('id', '=', $permission)->firstOrFail();

                $model = Role::where('name', '=', $name)->first();
                $model->givePermissionTo($p);
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }

        LogHelper::created_log($model);
		return [
			'message' => config('constants.success.created'),
			'status' => true
		];
    }
    public function update($request, $id)
    {
        $rules = [
            'name' => 'required',
        ];

        $message = [
            'name.required' => 'Nama Role wajib diisi',
        ];

        Validator::validate($request->all(), $rules, $message);

        DB::beginTransaction();
        try {

            $model = $this->model->findOrFail($id);

            $model->update($request->all());

            $p_all = Permission::all();//Get all permissions

            foreach ($p_all as $p) {
                $model->revokePermissionTo($p); //Remove all permissions associated with role
            }

            foreach ($request->permissions as $permission) {
                $p = Permission::where('id', '=', $permission)->firstOrFail(); //Get corresponding form //permission in db
                $model->givePermissionTo($p);  //Assign permission to role
            }

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }

        LogHelper::updated_log($model);
		return [
			'message' => config('constants.success.updated'),
			'status' => true
		];
    }
    public function delete($id)
    {
        $model = $this->model->findOrFail($id);

        try {
            $model->delete();
        } catch (\Exception $e) {
            return [
                'status'=>false,
                'message'=>$e->getMessage()
            ];
        }
        LogHelper::deleted_log($model);
        return [
			'message' => config('constants.success.deleted'),
			'status' => true
		];
	}


}


