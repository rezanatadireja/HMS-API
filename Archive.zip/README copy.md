## Abbout Resource

CASE MIX API
