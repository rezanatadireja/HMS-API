<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Permission;
use App\Models\Role;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        if ($this->command->confirm('Menjalankan migrasi akan menghapus data anda, lanjutkan ?')) {
            $this->command->call('migrate:fresh');
            $this->command->warn("Data sudah di reset, data anda ksosong dialam database.");
        }
        // Seed the default permissions
        $permissions = Permission::defaultPermissions();

        foreach ($permissions as $perms) {
            Permission::firstOrCreate(['name' => $perms]);
        }

        $this->command->info('Permission Default telah ditambahkan.');
        // Confirm roles needed
        if ($this->command->confirm('Lanjutkan dengan buat Role untuk pengguna, Default role yang kami Sarankan yaitu Admin dan User? [y|N]', true)) {

            // Ask for roles from input
            $input_roles = $this->command->ask('Masukan Nama Role , pisahkan dengan koma jika lebih dari satu role yang akan dibuat.', 'Admin,User');

            // Explode roles
            $roles_array = explode(',', $input_roles);

            // add roles
            foreach($roles_array as $role) {
                $role = Role::firstOrCreate(['name' => trim($role)]);

                if( $role->name == 'Admin') {
                    // assign all permissions
                    $role->syncPermissions(Permission::all());
                    $this->command->info('Role Admin telah diberikan akses ke semua permission');
                } else {
                    // for others by default only read access
                    $role->syncPermissions(Permission::where('name', 'LIKE', 'view_%')->get());
                }

                // create one user for each role
                $this->createUser($role);
            }

            $this->command->info('Roles ' . $input_roles . ' berhasil ditambahkan');

        } else {
            Role::firstOrCreate(['name' => 'User']);
            $this->command->info('Telah menambahkan hanya Role User.');
        }
    }

    private function createUser($role)
    {

        $user = User::create([
            'name'  => 'superadmin',
            'username'  => 'superadmin',
            'email' => 'superadmin@simrs.id',
            'status' => 1,
            'password'  => Hash::make('superadmin')
        ]);

        $user->assignRole($role->name);

        if( $role->name == 'Admin' ) {
            $this->command->info('Berikut adalah informasi Login Superadmin anda :');
            $this->command->warn($user->name);
            $this->command->warn('Password is "superadmin"');
        }

        \Artisan::call('auth:permission permission');
        \Artisan::call('auth:permission user');
        \Artisan::call('auth:permission role');
        \Artisan::call('auth:permission menu-management');
        \Artisan::call('auth:permission permission:cache-reset');

    }
}
