<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('operational_times', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->string('name', 50);
            $table->char('start_time_1', 5);
            $table->char('end_time_1', 5);
            $table->char('start_time_2', 5);
            $table->char('end_time_2', 5);
            $table->char('start_time_3', 5);
            $table->char('end_time_3', 5);
            $table->char('start_time_4', 5);
            $table->char('end_time_4', 5);
            $table->char('start_time_5', 5);
            $table->char('end_time_5', 5);
            $table->string('time_back_color', 10);
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('operational_times');
    }
};
