<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('item_groups', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('ref_item_type')->nullable();
            $table->string('name', 100);
            $table->decimal('cito_value', 18, 2);
            $table->tinyInteger('is_cito_in_patient')->nullable();
            $table->string('initial', 8)->nullable();
            $table->string('restriction_user_type', 150)->nullable();
            $table->tinyInteger('status')->default('1');
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('item_groups');
    }
};
