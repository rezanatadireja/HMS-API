<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('locations', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('parent_id')->nullable();
            $table->uuid('item_group_id');
            $table->uuid('permit_id')->nullable();
            $table->uuid('ref_type_of_inventory')->nullable();
            $table->uuid('ref_stock_group')->nullable();
            $table->uuid('chart_of_account_id_income')->nullable();
            $table->uuid('subledger_id_income')->nullable();
            $table->uuid('chart_of_account_id_inventory')->nullable();
            $table->uuid('chart_of_account_id_cogs')->nullable();
            $table->uuid('subledger_id_cogs')->nullable();
            $table->uuid('chart_of_account_id_sales_return')->nullable();
            $table->uuid('subledger_id_sales_return')->nullable();
            $table->uuid('chart_of_account_id_purchase_return')->nullable();
            $table->uuid('subledger_id_purchase_return')->nullable();
            $table->uuid('chart_of_account_id_acrual')->nullable();
            $table->uuid('subledger_id_acrual')->nullable();
            $table->uuid('chart_of_account_id_discount')->nullable();
            $table->uuid('subledger_id_discount')->nullable();
            $table->uuid('chart_of_account_id_cost')->nullable();
            $table->uuid('subledger_id_cost')->nullable();
            $table->string('name')->unique();
            $table->string('short_name')->unique();
            $table->tinyInteger('is_header')->default(0);
            $table->tinyInteger('is_hold_for_transaction')->default(0);
            $table->tinyInteger('is_allowed_to_stock_goods')->default(0);
            $table->tinyInteger('is_consignment')->default(0);
            $table->tinyInteger('is_validate_max_value_on_dist_req_for_ipm')->default(0);
            $table->tinyInteger('is_validate_max_value_on_dist_req_for_ipnm')->default(0);
            $table->tinyInteger('is_validate_max_value_on_dist_req_for_ik')->default(0);
            $table->tinyInteger('is_validate_max_value_on_purc_req_for_ipm')->default(0);
            $table->tinyInteger('is_validate_max_value_on_purc_req_for_ipnm')->default(0);
            $table->tinyInteger('is_validate_max_value_on_purc_req_for_ik')->default(0);
            $table->dateTime('last_hold_for_transaction_date_time')->nullable();
            $table->uuid('last_hold_for_transaction_by_user_id')->nullable();
            $table->tinyInteger('is_auto_update_stock_min_max')->default(0);
            $table->tinyInteger('status')->default('1');
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();

            $table->foreign('item_group_id')->references('id')->on('item_groups')->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('locations');
    }
};
