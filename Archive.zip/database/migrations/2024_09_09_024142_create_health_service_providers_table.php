<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('health_service_providers', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('teritory_id')->nullable();
            $table->string('name', 200)->nullable();
            $table->string('address_line_1', 200)->nullable();
            $table->string('address_line_2', 200)->nullable();
            $table->string('zip_code', 10)->nullable();
            $table->string('phone_no', 20)->nullable();
            $table->string('fax_no', 20)->nullable();
            $table->string('code', 10)->nullable();
            $table->string('bpjs_code', 10)->nullable();
            $table->string('email_address', 100)->nullable();
            $table->string('website', 200)->nullable();
            $table->string('npwp', 200)->nullable();
            $table->string('hospital_type', 200)->nullable();
            $table->string('additional_info', 200)->nullable();
            $table->string('logo', 200)->nullable();
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('health_service_providers');
    }
};
