<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('beds', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('room_id');
            $table->uuid('ref_bed_status');
            $table->uuid('old_bed_id')->nullable();
            $table->uuid('default_charge_class_id')->nullable();
            $table->string('registration_no', 20)->nullable();
            $table->string('bed_status_updated_by', 40);
            $table->tinyInteger('is_temporary')->default('0');
            $table->tinyInteger('is_need_confirmation');
            $table->tinyInteger('is_room_in');
            $table->dateTime('booking_date_time')->nullable();
            $table->tinyInteger('is_visible_3rd_party')->nullable();
            $table->tinyInteger('status')->default('1');
            $table->longText('notes', 500)->nullable();
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('beds');
    }
};
