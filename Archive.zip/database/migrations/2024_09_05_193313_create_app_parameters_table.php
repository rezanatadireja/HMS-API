<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('app_parameters', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->string('name', 1000)->nullable();
            $table->string('value', 1000)->nullable();
            $table->tinyInteger('type')->default(0);
            $table->tinyInteger('is_used_by_system')->default(0);
            $table->string('message', 2000)->nullable();
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('app_parameters');
    }
};
