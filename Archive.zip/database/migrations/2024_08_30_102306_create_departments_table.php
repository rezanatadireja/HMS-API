<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('departments', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('department_type_id');
            $table->uuid('parent_id')->nullable();
            $table->uuid('building_id');
            $table->uuid('floor_id');
            $table->string('name')->unique();
            $table->string('short_name')->unique();
            $table->string('code')->unique();
            $table->tinyInteger('is_using_job_order');
            $table->tinyInteger('is_patient_transaction');
            $table->tinyInteger('is_dispensary_unit');
            $table->tinyInteger('is_purchasing_unit');
            $table->tinyInteger('status')->default('1');
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->timestamps();

            $table->foreign('building_id')->references('id')->on('buildings')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('department_type_id')->references('id')->on('department_types')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('floor_id')->references('id')->on('floors')->onUpdate('cascade')->onDelete('restrict');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('departments');
    }
};
