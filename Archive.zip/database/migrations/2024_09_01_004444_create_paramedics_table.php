<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('paramedics', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('employee_id');
            $table->uuid('ref_paramedic_type');
            $table->uuid('ref_paramedic_status');
            $table->uuid('ref_speciality');
            $table->string('name', 100);
            $table->string('initial', 5);
            $table->date('date_of_birth');
            $table->longText('notes');
            $table->tinyInteger('status')->default('1');
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('paramedics');
    }
};
