<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('service_rooms', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('department_id');
            $table->uuid('floor_id');
            $table->uuid('ref_gender_type')->nullable();
            $table->string('name', 100);
            $table->tinyInteger('is_operation_room')->nullable();
            $table->tinyInteger('is_bpjs')->nullable();
            $table->tinyInteger('is_isolation_room')->nullable();
            $table->tinyInteger('is_negative_pressure_room')->nullable();
            $table->tinyInteger('is_pandemic_room')->nullable();
            $table->tinyInteger('is_ventilator')->nullable();
            $table->tinyInteger('status')->default('1');
            $table->longText('notes');
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();

            $table->foreign('department_id')->references('id')->on('departments')->onUpdate('cascade')->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('service_rooms');
    }
};
