<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('paramedic_schedules', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('paramedic_id');
            $table->uuid('service_unit_id');
            $table->string('period_year', 4);
            $table->integer('exam_duration')->nullable();
            $table->longText('notes');
            $table->smallInteger('quota')->nullable();
            $table->smallInteger('quota_online')->nullable();
            $table->smallInteger('quota_bpjs')->nullable();
            $table->smallInteger('quota_bpjs_online')->nullable();
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();

            $table->foreign('paramedic_id')->references('id')->on('paramedics')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('service_unit_id')->references('id')->on('service_units')->onUpdate('cascade')->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('paramedic_schedules');
    }
};
