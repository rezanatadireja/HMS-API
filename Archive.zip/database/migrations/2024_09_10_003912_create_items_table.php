<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('items', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('item_group_id');
            $table->uuid('asset_group_id')->nullable();
            $table->uuid('ref_item_type');
            $table->uuid('ref_billing_group');
            $table->uuid('ref_item_category');
            $table->uuid('ref_item_sub_group');
            $table->string('name', 200);
            $table->tinyInteger('is_item_production')->nullable();
            $table->string('barcode', 35)->nullable();
            $table->string('image')->nullable();
            $table->dateTime('validity_period_from')->nullable();
            $table->dateTime('validity_period_to')->nullable();
            $table->tinyInteger('is_asset')->nullable();
            $table->tinyInteger('is_delegation_to_nurse')->nullable();
            $table->tinyInteger('is_new_upload')->nullable();
            $table->tinyInteger('status')->default('1');
            $table->longText('notes');
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();

            $table->foreign('item_group_id')->references('id')->on('item_groups')->onUpdate('cascade')->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('items');
    }
};
