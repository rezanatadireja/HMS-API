<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('guarantors', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('ref_guarantor_type');
            $table->uuid('ref_business_method')->nullable();
            $table->uuid('ref_guarantor_rule_type')->nullable();
            $table->uuid('ref_payment_type')->nullable();
            $table->string('code', 25);
            $table->string('name', 100);
            $table->string('short_name', 100);
            $table->string('contract_number', 100)->nullable();
            $table->date('contract_start')->nullable();
            $table->date('contract_end')->nullable();
            $table->text('contract_summary')->nullable();
            $table->string('street_name', 250);
            $table->uuid('teritory_id')->nullable();
            $table->uuid('country_id')->nullable();
            $table->string('zip_code', 15)->nullable();
            $table->string('phone_no', 100);
            $table->string('fax_no', 50);
            $table->string('email', 100)->nullable();
            $table->string('mobile_phone_no', 20);
            $table->tinyInteger('is_cover_inpatient');
            $table->tinyInteger('is_cover_outpatient');
            $table->tinyInteger('status')->default('1');
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('guarantors');
    }
};
