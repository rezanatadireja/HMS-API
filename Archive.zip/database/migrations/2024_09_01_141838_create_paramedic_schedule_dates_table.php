<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('paramedic_schedule_dates', function (Blueprint $table) {
            $table->uuid('id', 36)->primary();
            $table->uuid('service_unit_id');
            $table->uuid('paramedic_id');
            $table->uuid('operational_time_id');
            $table->string('period_year', 4);
            $table->dateTime('schedule_date');
            $table->tinyInteger('is_closed_time_1')->nullable();
            $table->tinyInteger('losed_time_1')->nullable();
            $table->tinyInteger('closed_time_1_by_user_id')->nullable();
            $table->tinyInteger('is_closed_time_2')->nullable();
            $table->tinyInteger('losed_time_2')->nullable();
            $table->tinyInteger('closed_time_2_by_user_id')->nullable();
            $table->tinyInteger('is_closed_time_3')->nullable();
            $table->tinyInteger('losed_time_3')->nullable();
            $table->tinyInteger('closed_time_3_by_user_id')->nullable();
            $table->tinyInteger('is_closed_time_4')->nullable();
            $table->tinyInteger('losed_time_4')->nullable();
            $table->tinyInteger('closed_time_4_by_user_id')->nullable();
            $table->tinyInteger('is_closed_time_5')->nullable();
            $table->tinyInteger('losed_time_5')->nullable();
            $table->tinyInteger('closed_time_5_by_user_id')->nullable();
            $table->tinyInteger('is_ipr')->nullable();
            $table->tinyInteger('is_opr')->nullable();
            $table->tinyInteger('is_emr')->nullable();
            $table->string('period_month', 2)->nullable();
            $table->smallInteger('add_quota')->nullable();
            $table->smallInteger('add_quota_online')->nullable();
            $table->smallInteger('add_quota_bpjs')->nullable();
            $table->smallInteger('add_quota_bpjs_online')->nullable();
            $table->uuid('created_by')->nullable();
            $table->uuid('updated_by')->nullable();
            $table->uuid('owner_user_id')->nullable();
            $table->timestamps();

            $table->foreign('service_unit_id')->references('id')->on('service_units')->cascadeOnUpdate()->restrictOnDelete();
            $table->foreign('paramedic_id')->references('id')->on('paramedics')->cascadeOnUpdate()->restrictOnDelete();
            $table->foreign('operational_time_id')->references('id')->on('operational_times')->cascadeOnUpdate()->restrictOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('paramedic_schedule_dates');
    }
};
